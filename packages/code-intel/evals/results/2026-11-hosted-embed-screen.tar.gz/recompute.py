"""Recompute the decision of the hosted embedding screen from the uploaded rows (stdlib only).

Usage: python3 recompute.py DESIGN.json WORK_DIR  -> prints the decision JSON.
"""
import hashlib
import json
import math
import sys
from pathlib import Path

RRF_K, RRF_DEPTH = 60, 48  # eval.matrix.arms


def rrf(orders):
    scores = {}
    for order in orders:
        for rank, path in enumerate(order[:RRF_DEPTH]):
            scores[path] = scores.get(path, 0.0) + 1.0 / (RRF_K + rank + 1)
    return sorted(scores, key=lambda path: (-scores[path], path))


def acc(files, gold, k):
    return len(set(files[:k]) & set(gold)) >= min(len(gold), k)


def sign_p(wins, losses):
    n = wins + losses
    return 1.0 if n == 0 else sum(math.comb(n, i) for i in range(wins, n + 1)) / 2**n


design_path, work = Path(sys.argv[1]), Path(sys.argv[2])
assert hashlib.sha256(design_path.read_bytes()).hexdigest() == (
    "03144ca0ae0c67ae34ba178730d316bc8c4410dddff30cdcd99c4be2e94622ea"
)
design = json.loads(design_path.read_text())
tasks = {t["id"]: t for t in design["tasks"]}
assert len(tasks) == 50
product = sum(t["acc5"]["product"] for t in tasks.values())
assert product == design["reference"]["hits5"]["product"]
models, hit_sets = {}, {}
for model in design["models"]:
    slug = model["id"].replace("/", "__")
    path = work / f"rows-{slug}.jsonl"
    if not path.exists():
        models[model["id"]] = {"verdict": "not run"}
        continue
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    # The harness built each row id before it rebound tid (tuple assignment), so row i
    # carries the id of task i-1. Rows follow design order; relabel by position.
    assert len(rows) == len(tasks) and all(r["model"] == model["id"] for r in rows)
    assert [r["id"] for r in rows] == [list(tasks)[i - 1] for i in range(len(tasks))]
    rows = [{**r, "id": tid, "label_in_file": r["id"]} for r, tid in zip(rows, tasks)]
    ok = {}
    for r in rows:
        if r["status"] != "ok":
            continue
        t = tasks[r["id"]]
        assert len(r["files"]) == len(set(r["files"])) <= 48
        assert r["rrf"] == rrf([t["product"], r["files"]])[:48]
        assert r["acc5_model"] == acc(r["files"], t["gold"], 5)
        assert r["acc5_rrf"] == acc(r["rrf"], t["gold"], 5)
        ok[r["id"]] = r
    fused = {tid: bool(ok.get(tid, {}).get("acc5_rrf")) for tid in tasks}
    wins = sum(fused[t] and not tasks[t]["acc5"]["product"] for t in tasks)
    losses = sum(tasks[t]["acc5"]["product"] and not fused[t] for t in tasks)
    hits = {"rrf": sum(fused.values()), "model": sum(r["acc5_model"] for r in ok.values())}
    summary = work / f"summary-{slug}.json"
    spent = json.loads(summary.read_text())["spent_usd"] if summary.exists() else None
    out = {
        "ok": len(ok),
        "incomplete": len(tasks) - len(ok),
        "hits5": hits,
        "product_hits5": product,
        "net": hits["rrf"] - product,
        "wins": wins,
        "losses": losses,
        "sign_p": round(sign_p(wins, losses), 6),
        "spent_usd": spent,
    }
    if out["incomplete"] > 2:
        out["verdict"] = "incomplete"
    else:
        out["verdict"] = "pass" if out["net"] >= 5 and out["sign_p"] <= 0.05 else "fail"
    alone = {tid: bool(ok.get(tid, {}).get("acc5_model")) for tid in tasks}

    def pair(a, b):  # tasks where a hits and b misses, and the reverse
        return [sum(a[t] and not b[t] for t in tasks), sum(b[t] and not a[t] for t in tasks)]

    prod = {t: tasks[t]["acc5"]["product"] for t in tasks}
    fnd = {t: tasks[t]["acc5"]["fn_dense"] for t in tasks}
    out["not_gated"] = {
        "model_vs_product": pair(alone, prod),
        "model_vs_fn_dense": pair(alone, fnd),
        "rrf_vs_fn_dense": pair(fused, fnd),
        "model_vs_rrf": pair(alone, fused),
    }
    models[model["id"]] = out
    hit_sets[model["id"]] = alone
passing = [m for m, r in models.items() if r["verdict"] == "pass"]
winner = min(
    passing,
    key=lambda m: (-models[m]["hits5"]["rrf"], -models[m]["hits5"]["model"], models[m]["spent_usd"] or 0.0),
    default=None,
)
a, b = (hit_sets.get(m["id"]) for m in design["models"])
both = {"model_hits_both": sum(a[t] and b[t] for t in tasks), "model_hits_either": sum(a[t] or b[t] for t in tasks)} if a and b else None
print(json.dumps({"design": design["name"], "reference_hits5": design["reference"]["hits5"],
                  "models": models, "winner": winner, "models_agreement": both}, indent=1))
