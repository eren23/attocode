"""Independent stdlib recompute of the test-recall development screen (no eval imports)."""
import glob, hashlib, json, re, sys
root = sys.argv[1]
def load(arm):
    rows, meta = {}, set()
    for f in sorted(glob.glob(f"{root}/obs/{arm}/*.json")):
        r = json.load(open(f))
        meta.add((r["operator_sha256"], r["engine_sha256"], r["questions_sha256"]))
        for q in r["queries"]:
            rows[q["id"]] = q
    return rows, meta
B, mb = load("baseline"); C, mc = load("candidate")
assert mb == mc and len(mb) == 1 and set(B) == set(C)
def test_query(q):  # mirrors explicit_test_query: <=20 terms is checked separately below
    return re.search(r"\btests?\b", q, re.I) is not None
out = {"questions": len(B), "meta": sorted(mb)[0]}
for page in ("5", "24", "scoped"):
    out[f"files_{page}"] = [sum(len(R[i]["pages"][page]["hits"]["files"]) for i in R) for R in (B, C)]
    out[f"visible_{page}"] = [sum(len(R[i]["pages"][page]["hits"]["visible"]) for i in R) for R in (B, C)]
net = {}
for i in B:
    pack = B[i]["pack"]
    net[pack] = net.get(pack, 0) + len(C[i]["pages"]["5"]["hits"]["files"]) - len(B[i]["pages"]["5"]["hits"]["files"])
out["files_5_net_by_pack"] = net
out["file_losses"] = [{"id": i, "page": p, "lost": sorted(set(B[i]["pages"][p]["hits"]["files"]) - set(C[i]["pages"][p]["hits"]["files"]))}
                      for i in B for p in ("5", "24")
                      if set(B[i]["pages"][p]["hits"]["files"]) - set(C[i]["pages"][p]["hits"]["files"])]
out["test_queries"] = sum(test_query(B[i]["query"]) for i in B)
out["changed_controls"] = [i for i in B if not test_query(B[i]["query"]) and any(
    B[i]["pages"][p]["response"]["data"]["results"] != C[i]["pages"][p]["response"]["data"]["results"] for p in ("5", "24", "scoped"))]
out["changed_test_queries"] = sum(test_query(B[i]["query"]) and any(
    B[i]["pages"][p]["response"]["data"]["results"] != C[i]["pages"][p]["response"]["data"]["results"] for p in ("5", "24", "scoped")) for i in B)
gain = sum(net.values())
out["gates"] = {"files_5_gain": gain >= 2 and sum(v > 0 for v in net.values()) >= 2,
                "no_file_loss_5": not any(x["page"] == "5" for x in out["file_losses"]),
                "no_file_loss_24": not any(x["page"] == "24" for x in out["file_losses"]),
                "controls_identical": not out["changed_controls"]}
d = json.load(open(f"{root}/decision.json"))
for k, v in out["gates"].items():
    assert d["checks"][k] == v, k
assert d["trial"]["files_5_net_by_pack"] == net and d["trial"]["changed_controls"] == out["changed_controls"]
assert [d["baseline"]["files_24"], d["candidate"]["files_24"]] == out["files_24"]
out["decision_sha256"] = hashlib.sha256(open(f"{root}/decision.json", "rb").read()).hexdigest()
out["matches_decision"] = True
print(json.dumps(out, indent=1))
