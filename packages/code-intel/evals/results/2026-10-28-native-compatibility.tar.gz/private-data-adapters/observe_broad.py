"""Observe the existing one attempt, preserve originals, then data-only admit."""
import concurrent.futures,json,pathlib,subprocess,sys
R=pathlib.Path(__file__).parent;d=json.loads((R/'broad-1-dispatch.json').read_bytes())['run'];ident=d['id'];head=d['head_sha']
def run(label,args):
 with (R/(label+'.log')).open('w') as stream:subprocess.run([sys.executable,*map(str,args)],stdout=stream,stderr=subprocess.STDOUT,check=True)
run('broad-1-watch',[R/'watch_attempt.py',ident,head,'broad-1'])
run('original-retention',[R/'retain_artifacts.py'])
ret=json.loads((R/'original-artifacts/retention.json').read_bytes())
if ret['conclusion']!='success':
 if next(a for a in ret['artifacts'] if a['kind']=='payload')['available']:
  run('broad-1-collect',[R/'collect_broad.py',ident,head,'broad',R/'broad-1'])
 print('FIRST_ATTEMPT_RETAINED_INCOMPLETE; inspect originals; no redispatch',ident,flush=True)
 raise SystemExit(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,'broad-1-collect',[R/'collect_broad.py',ident,head,'broad',R/'broad-1']),pool.submit(run,'platform-collect',[R/'collect_broad_platform.py',ident,head,'preflight',R/'broad-platform-controls'])]
 for f in futures:f.result()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,'broad-1-semantic',[R/'verify_broad.py',R/'broad-1']),pool.submit(run,'platform-semantic',[R/'verify_broad_platform.py'])]
 for f in futures:f.result()
print('ONE_FULL_MATRIX_AND_NATIVE_CAPTURE_ADMITTED',ident,head,flush=True)
