"""Independent byte/XML/source admission of the required remote Linux controls."""
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
attempt=ROOT/'broad-platform-controls'
proof=json.loads((attempt/'admission.json').read_bytes())
assert proof['outcome']=='passed' and proof['run']['status']=='completed' and proof['run']['conclusion']=='success'
head=proof['run']['head_sha'];run=proof['run']['id'];raw=(attempt/'artifact.zip').read_bytes()
assert hashlib.sha256(raw).hexdigest()==proof['archive_sha256']
assert proof['artifact']['digest']=='sha256:'+proof['archive_sha256']
assert proof['artifact']['name']==f'experiment-broad-platform-preflight-{run}-1'
with zipfile.ZipFile(attempt/'artifact.zip') as z:
 members=z.infolist();assert len(members)==len({m.filename for m in members}) and sum(m.file_size for m in members)<64*2**20
 for m in members:
  p=PurePosixPath(m.filename);assert not p.is_absolute() and '..' not in p.parts
  if not m.is_dir():assert (attempt/p).read_bytes()==z.read(m)
 reports=[m for m in members if PurePosixPath(m.filename).name=='report.json'];assert len(reports)==1
 evidence=attempt/PurePosixPath(reports[0].filename).parent
 report=json.loads(z.read(reports[0]));assert report==proof['report']
verified_members={m.filename for m in members if not m.is_dir()}
def read_evidence(name):
 path=evidence/name
 assert path.relative_to(attempt).as_posix() in verified_members
 return path.read_bytes()
assert report['status']=='complete' and report['decision'] is None and report['experiment']=='preflight'
assert report['identity']['commit']==head and report['identity']['github_run_id']==str(run)
assert 'Linux' in report['identity']['platform'] and 'x86_64' in report['identity']['platform']
assert report['seconds']<300 and report['owned_scratch_removed'] and report['cleanup_verified']
row=report['supervision'];assert row['status']=='passed' and row['exit_code']==0 and row['cleanup_verified'] and not row['log_truncated']
assert row['peak_rss_bytes']<2**31 and row['peak_disk_bytes']<2**31 and row['peak_evidence_bytes']<63*2**20
for name,digest in report['identity']['files'].items():
 assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+name])).hexdigest()==digest

def cases(raw):
 assert b'<!DOCTYPE' not in raw.upper()
 root=ET.fromstring(raw);assert not list(root.iter('failure')) and not list(root.iter('error'))
 result=set()
 for case in root.iter('testcase'):
  assert case.find('skipped') is None
  parts=case.get('classname').split('.');start=next(i for i,p in enumerate(parts) if p.startswith('test_'))
  identity='.'.join(parts[start:])+'::'+case.get('name');assert identity not in result;result.add(identity)
 return result
expected=set(json.loads((ROOT/'preflight-cases.json').read_bytes())['cases'])
actual=cases(read_evidence('preflight.xml'));assert actual==expected and len(actual)==373
records={name:json.loads(read_evidence(name)) for name in ('controller-origin.json','controller-complete.json','pytest-origin.json')}
assert records['controller-complete.json']['complete'] and records['pytest-origin.json']['exitstatus']==0
assert records['controller-origin.json']['pid']!=records['pytest-origin.json']['pid']
for record in records.values():
 assert record['origins']['attocode_intel']=='__init__.py'
 for module,relative in record['origins'].items():
  p=PurePosixPath(relative);assert module.startswith('attocode_intel') and not p.is_absolute() and '..' not in p.parts
  assert 'packages/code-intel/src/attocode_intel/'+relative in report['identity']['files']
out={'outcome':'passed','operator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'head':head,'run':run,'archive_sha256':proof['archive_sha256'],'controls':373,'platform':report['identity']['platform'],'same_head_origins_verified':True,'cleanup_verified':True,'seconds':report['seconds']}
(attempt/'semantic-admission.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
