"""One prospective maintained broad launch; refuse duplicate authorization/request."""
import hashlib,json,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;HEAD='5d34e37c114ba2f05d76b91905086b310e6aab18'
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/eren23/attocode/'+path],timeout=45))
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='main'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==api('branches/main')['commit']['sha']==HEAD
assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()=='?? AGENTS.md'
assert not api('actions/runs?status=in_progress&per_page=100')['workflow_runs'] and not api('actions/runs?status=queued&per_page=100')['workflow_runs']
pre=json.loads((R/'prelaunch-adapter-admission.json').read_bytes());assert pre['outcome']=='passed' and pre['head']==HEAD
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in pre['capture_source_sha256'].items())
design=Path('eval/quality/experiments/broad.json');d=json.loads(design.read_bytes());assert d['limits']=={'seconds':1200,'disk_bytes':2147483648,'rss_bytes':2147483648,'evidence_bytes':67108864} and d['per_pack_seconds']==180 and d['expected_packs']==36 and d['expected_questions']==144 and d['platform_preflight']['required_controls']==373
adapters={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in R.glob('*.py')}
with (R/'single-run-authorization.json').open('x') as f:json.dump({'head':HEAD,'design_sha256':hashlib.sha256(design.read_bytes()).hexdigest(),'workflow_sha256':hashlib.sha256(Path('.github/workflows/intelligence-experiments.yml').read_bytes()).hexdigest(),'adapter_sha256':adapters,'one_attempt':True,'no_rerun_resume_replacement_retune_capwaiver':True,'questions':'144existingconsumedoperationalanchors','new_relevance_or_performance_claim':False,'limits':d['limits'],'prelaunch_admission_sha256':hashlib.sha256((R/'prelaunch-adapter-admission.json').read_bytes()).hexdigest(),'created_unix':time.time()},f,indent=2)
old={x['id'] for x in api('actions/workflows/intelligence-experiments.yml/runs?per_page=100')['workflow_runs']}
with (R/'broad-1-request.json').open('x') as f:json.dump({'head':HEAD,'branch':'main','experiment':'broad','previous_run_ids':sorted(old),'created_unix':time.time()},f,indent=2)
subprocess.run(['gh','workflow','run','intelligence-experiments.yml','--repo','eren23/attocode','--ref','main','-f','experiment=broad'],check=True,timeout=45)
for _ in range(12):
 matches=[x for x in api('actions/workflows/intelligence-experiments.yml/runs?per_page=100')['workflow_runs'] if x['id'] not in old and x['head_sha']==HEAD and x['head_branch']=='main' and x['event']=='workflow_dispatch']
 if matches:
  assert len(matches)==1;run=matches[0];(R/'broad-1-dispatch.json').write_text(json.dumps({'run':run,'observed_unix':time.time()},indent=2)+'\n');print(json.dumps({k:run[k] for k in ('id','head_sha','status','html_url')}));break
 time.sleep(2)
else:raise RuntimeError('Request sent; metadata not found; DO NOT REDISPATCH')
