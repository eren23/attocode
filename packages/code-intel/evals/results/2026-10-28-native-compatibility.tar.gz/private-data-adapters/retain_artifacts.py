"""Preserve first-attempt original ZIPs before any success admission; data only."""
import hashlib,io,json,stat,subprocess,time,zipfile
from pathlib import Path,PurePosixPath
R=Path(__file__).parent;d=json.loads((R/'broad-1-dispatch.json').read_bytes())['run'];ident=d['id'];head=d['head_sha'];out=R/'original-artifacts';out.mkdir(exist_ok=False)
def get(path):return subprocess.check_output(['gh','api','repos/eren23/attocode/'+path],timeout=120)
run=json.loads(get(f'actions/runs/{ident}'));assert run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed'
listing=json.loads(get(f'actions/runs/{ident}/artifacts?per_page=100'));(out/'listing.json').write_text(json.dumps(listing,indent=2)+'\n');(out/'run.json').write_text(json.dumps(run,indent=2)+'\n');rows=[]
for kind,name in [('payload',f'experiment-broad-{ident}-1'),('platform',f'experiment-broad-platform-preflight-{ident}-1')]:
 found=[a for a in listing['artifacts'] if a['name']==name];assert len(found)<=1
 if not found:rows.append({'kind':kind,'available':False});continue
 a=found[0];assert not a['expired'] and a['workflow_run']['head_sha']==head and a['workflow_run']['id']==ident
 raw=get(f'actions/artifacts/{a["id"]}/zip');digest=hashlib.sha256(raw).hexdigest();assert len(raw)<64*2**20 and (not a.get('digest') or a['digest']=='sha256:'+digest)
 (out/(kind+'.zip')).write_bytes(raw)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  members=z.infolist();assert len(members)==len({m.filename for m in members}) and sum(m.file_size for m in members)<64*2**20
  assert all(not PurePosixPath(m.filename).is_absolute() and '..' not in PurePosixPath(m.filename).parts and not stat.S_ISLNK(m.external_attr>>16) for m in members)
 rows.append({'kind':kind,'available':True,'artifact':a,'sha256':digest,'bytes':len(raw),'members':len(members)})
(out/'retention.json').write_text(json.dumps({'run':ident,'head':head,'conclusion':run['conclusion'],'artifacts':rows,'observed_unix':time.time()},indent=2)+'\n');print(json.dumps({'retained_run':ident,'conclusion':run['conclusion'],'artifacts':[{k:a.get(k) for k in ['kind','available','sha256','bytes']} for a in rows]}))
