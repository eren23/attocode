"""Independent retained JSONL replay; stdlib only, no tested operator imports."""
import hashlib,json
SOURCE_KEYS=('eval/quality/native_capture.py','eval/quality/native_experiment.py','eval/quality/corpus.py','eval/quality/corpus_capture.py','packages/code-intel/src/attocode_intel/_internal/integrations/context/ts_parser.py')
COUNTS=('parse_calls','native_failures','capture_errors','dropped_events','oversized_events','protocol_errors','unfinished_parsers')
def admit_native(raw,summary,spec,workspace,files,pid):
 assert isinstance(summary,dict) and summary['status']=='complete' and summary['bytes']==len(raw)
 assert len(raw)<=4*2**20 and raw.endswith(b'\n')
 lines=raw.splitlines();records=[json.loads(x) for x in lines];start,end=records[0],records[-1]
 assert start['kind']=='trace_start' and type(start['schema_version']) is int and start['schema_version']==2
 assert start['workspace']==workspace and start['fixture']=={k:spec.get(k) for k in ('id','repo','commit','language','file','source_sha256')}
 assert start['sources']=={k:files[k] for k in SOURCE_KEYS}
 assert type(start['runtime']['pid']) is int and start['runtime']['pid']==pid
 assert start['limits']=={'max_bytes':4194304,'event_bytes':65536,'prefix_bytes':3142656,'tail_bytes':1047552}
 assert end['kind']=='trace_end' and end['status']=='complete' and end['worker_error'] is None and summary['worker_error'] is None
 for name in COUNTS:
  assert type(end[name]) is int and type(summary[name]) is int and end[name]==summary[name]>=0
  if name not in {'parse_calls','native_failures'}:assert end[name]==0
 states={};identities=set();parsed=[];resets=0;last=-1
 for index,(line,item) in enumerate(zip(lines,records,strict=True),1):
  assert type(item['index']) is int and item['index']==index and type(item['monotonic_ns']) is int and item['monotonic_ns']>=last
  last=item['monotonic_ns'];kind=item['kind']
  if kind=='trace_start':assert index==1 and len(line)+1<=3142656;continue
  if kind=='trace_end':assert index==len(records) and len(line)+1<=4096;continue
  assert kind=='native' and len(line)+1<=65536
  row=item['native'];assert type(row['thread_id']) is int and row['thread_id']>0
  if row['stage']=='lookup' and row['available'] is False:assert row['language']=='ocaml';continue
  key=row['parser_generation'],row['parser_id'],row['thread_id'];assert all(type(part) is int and part>0 for part in key);identities.add(key)
  stage=row['stage']
  if stage=='parser':
   assert row['origin'] in {'primary','generic','use'} and row['language']=='ocaml' and states.get(key) in {None,'idle'};states[key]='idle'
  elif stage=='timeout_set':
   assert states[key]=='idle' and type(row['value']) is int and row['value']==100000;states[key]='armed'
  elif stage=='parse':
   assert states[key]=='armed' and row['language']=='ocaml' and type(row['limit_micros']) is int and row['limit_micros']==100000
   assert all(type(row[n]) is int and row[n]>=0 for n in ('wall_ns','thread_cpu_ns','bytes'))
   assert isinstance(row['source_sha256'],str) and len(row['source_sha256'])==64 and set(row['source_sha256'])<=set('0123456789abcdef')
   assert isinstance(row['thread_name'],str) and row['thread_name']
   if row['error'] is None:assert row['outcome'] in {'tree','no_tree'}
   else:assert row['error']['type']==row['outcome'] and isinstance(row['error']['message'],str) and len(row['error']['message'])<=2000
   states[key]='parsed';parsed.append(row)
  elif stage=='reset':
   assert states.pop(key)=='parsed';resets+=1
  else:raise AssertionError('Unknown native stage')
 assert all(v=='idle' for v in states.values()) and len(parsed)==resets==end['parse_calls']
 assert sum(x['outcome']!='tree' for x in parsed)==end['native_failures']
 selected=sum(x['source_sha256']==spec['source_sha256'] for x in parsed)
 return {'status':'passed','parse_calls':len(parsed),'native_failures':end['native_failures'],'selected_source_parses':selected,'parser_generation_thread_pairs':len(identities),'threads':len({x['thread_id'] for x in parsed}),'worker_pid':pid,'trace_sha256':hashlib.sha256(raw).hexdigest(),'trace_bytes':len(raw),'source_origin_clock_lifecycle_verified':True}
