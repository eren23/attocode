"""Replay consumed development observations; initial fallback run is invalid."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
from compare import decide
from trial import judged

manifest = json.loads((ROOT / 'manifest.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
questions = json.loads((ROOT / 'questions.json').read_text())
labels = {q['id']: q['evidence'] for group in questions['repositories'] for q in group['queries']}
reports = [json.loads((ROOT / (pack + '-pages.json')).read_text()) for pack in ('express', 'prisma')]
for report in reports:
    for page in report['pages']:
        assert judged(page['page'], labels[page['id']]) == page['judged'], (page['id'], page['arm'])
    for control in report['controls']:
        assert control['baseline']['data'] == control['candidate']['data']
    b, c = [report['representation'][arm] for arm in ('baseline', 'candidate')]
    assert c['test_units'] and c['body_counts']['test_case'] == len(c['test_units'])
    assert b['keyword_sha256'] == c['keyword_sha256']
    assert b['function_method_windows_sha256'] == c['function_method_windows_sha256']
decision = json.loads(json.dumps(decide(reports, questions)))
stored = json.loads((ROOT / 'decision.json').read_text())
assert all(value == stored[key] for key, value in decision.items())
assert stored['evidence_scope'] == 'consumed_development'
assert stored['fresh_validation_performed'] is False
print(json.dumps({'status': decision['status'], 'scope': stored['evidence_scope'],
                  'pages': sum(len(r['pages']) for r in reports), 'counts': decision['counts'],
                  'loss_observations': len(decision['losses'])}))
