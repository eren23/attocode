"""Supervise the frozen comparison and recompute every no-loss gate."""
import hashlib
import json
import math
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

from eval.quality import runner
from eval.quality.mcp_search import engine_identity

HERE = Path(__file__).resolve().parent


def identity():
    return {'engine_sha256': engine_identity(), 'inputs': {
        name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
        for name in ('questions.json', 'source-manifest.json', 'candidate.py', 'trial.py', 'compare.py')}}


def decide(reports, questions):
    expected = {q['id']: group['pack'] for group in questions['repositories'] for q in group['queries']}
    pages = [p for report in reports for p in report['pages']]
    matrix = {(p['id'], p['arm'], p['round'], p['depth']): p for p in pages}
    assert len(matrix) == len(pages) == 24 * 2 * 3 * 2
    assert set(matrix) == {(qid, arm, round_, depth) for qid in expected
                           for arm in ('baseline', 'candidate') for round_ in range(3) for depth in (5, 24)}
    gains, losses = [], []
    for qid in expected:
        for round_ in range(3):
            for depth in (5, 24):
                b, c = [matrix[qid, a, round_, depth]['judged'] for a in ('baseline', 'candidate')]
                for kind in ('files', 'excerpts'):
                    for label in set(b[kind]) - set(c[kind]):
                        losses.append({'id': qid, 'round': round_, 'depth': depth, 'kind': kind, 'label': label})
                if depth == 5:
                    gains.extend((qid, f) for f in set(c['files']) - set(b['files']))
    gains = sorted(set(gains))
    gains_by_round = [set((qid, f) for qid in expected for f in
                         set(matrix[qid, 'candidate', r, 5]['judged']['files']) -
                         set(matrix[qid, 'baseline', r, 5]['judged']['files'])) for r in range(3)]
    p95 = {}
    for round_ in range(3):
        p95[round_] = {}
        for arm in ('baseline', 'candidate'):
            times = sorted(p['seconds'] for p in pages if p['round'] == round_ and p['arm'] == arm)
            p95[round_][arm] = times[math.ceil(.95 * len(times)) - 1]
    checks = {'two_new_first_page_matches_every_round': all(len(g) >= 2 for g in gains_by_round),
              'gains_in_both_repositories_every_round': all({expected[q] for q, _ in g} == {'express', 'prisma'} for g in gains_by_round),
              'no_file_or_excerpt_loss': not losses,
              'controls_identical': all(c['unchanged'] for report in reports for c in report['controls']),
              'warm_p95_each_round': all(p['candidate'] <= max(1.25 * p['baseline'], .05) for p in p95.values()),
              'cleanup_verified': all(report['scratch_removed'] for report in reports)}
    return {'status': 'accepted' if all(checks.values()) else 'rejected', 'checks': checks,
            'gains': gains, 'losses': losses, 'p95_seconds': p95,
            'counts': {str(depth): {arm: {
                kind: sum(len(matrix[qid, arm, 0, depth]['judged'][kind]) for qid in expected)
                for kind in ('files', 'excerpts')} for arm in ('baseline', 'candidate')} for depth in (5, 24)}}


def main():
    before = identity()
    frozen = json.loads((HERE / 'candidate-freeze.json').read_text())
    assert before == frozen['identity']
    if (HERE / 'comparison-runtime.json').exists():
        raise ValueError('One frozen comparison only; preserve previous attempt')
    root = Path(tempfile.mkdtemp(prefix='attocode-test-spans-controlled-'))
    for name in ('work', 'cache'):
        (root / name).mkdir()
    rows, reports = [], []
    started = time.monotonic()
    try:
        for pack in ('express', 'prisma'):
            env = runner.environment(root)
            env.pop('QUALITY_ALLOW_DOWNLOADS', None)
            env['PYTHONPATH'] = str(runner.REPO / 'packages/code-intel/src') + os.pathsep + str(runner.REPO)
            row = runner.supervise([sys.executable, str(HERE / 'trial.py'), '--pack', pack,
                                    '--output', str(HERE / (pack + '-pages.json'))],
                                   cwd=runner.REPO, env=env, root=root, log=HERE / (pack + '.log'),
                                   deadline=min(started + 300, time.monotonic() + 180),
                                   wall_deadline=time.time() + min(180, 300 - (time.monotonic() - started)),
                                   max_bytes=2 * 2**30, max_rss=2 * 2**30)
            rows.append({'pack': pack, **row})
            (HERE / 'comparison-runtime.json').write_text(json.dumps({'identity_before': before, 'runs': rows}, indent=2))
            print(json.dumps({'pack': pack, 'status': row['status'], 'seconds': row['seconds']}), flush=True)
            if row['status'] != 'passed':
                raise ValueError('Frozen comparison incomplete, retain failed attempt')
            reports.append(json.loads((HERE / (pack + '-pages.json')).read_text()))
        result = decide(reports, json.loads((HERE / 'questions.json').read_text()))
        assert before == identity()
        (HERE / 'decision.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
    finally:
        shutil.rmtree(root)
        (HERE / 'comparison-runtime.json').write_text(json.dumps({
            'identity_before': before, 'identity_after': identity(), 'runs': rows,
            'seconds': time.monotonic() - started, 'scratch_removed': not root.exists()}, indent=2))


if __name__ == '__main__':
    main()
