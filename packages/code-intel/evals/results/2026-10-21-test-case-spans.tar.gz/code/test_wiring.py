from pathlib import Path
from unittest.mock import patch

from attocode_intel._internal.integrations.context import semantic_search
from attocode_intel._internal.integrations.context.codebase_ast import parse_file
from attocode_intel._internal.integrations.context.semantic_search import SemanticSearchManager
from trial import index_evidence, spans_for


def test_span_adapter_accepts_resolved_ast_paths_for_an_alias_workspace(tmp_path):
    real = tmp_path/'real'
    real.mkdir()
    (real/'tests').mkdir()
    file = real/'tests/example.js'
    file.write_text("it('literal title', () => { check(); });")
    alias = tmp_path/'alias'
    alias.symlink_to(real, target_is_directory=True)
    symbols, _ = spans_for(alias, semantic_search._source_spans)(parse_file(str(file.resolve())))
    assert any(span[2] == 'test_case' for span in symbols)


def test_candidate_indexes_search_units_without_navigation_definitions(tmp_path):
    source = "it('cobalt sentinel', () => {\n  expect(cobalt()).toBe('sentinel');\n});\n"
    path = tmp_path/'test/sample.js'
    path.parent.mkdir()
    path.write_text(source)
    before = parse_file(str(path)).get_symbols()
    manager = SemanticSearchManager(str(tmp_path))
    try:
        original = semantic_search._source_spans
        with patch.object(semantic_search, '_source_spans', spans_for(Path(tmp_path), original)):
            manager.search('warmup', top_k=5)
            assert manager.wait_for_body_index(timeout=10)
        hits = manager.search_candidates('test cobalt sentinel', top_k=24)
        selected = [h for h in hits if h.chunk_type == 'test_case']
        assert selected and 'cobalt sentinel' in selected[0].name
        assert (selected[0].start_line, selected[0].end_line) == (1, 3)
        assert "expect(cobalt()).toBe('sentinel');" in selected[0].text
        assert index_evidence(tmp_path)['body_counts']['test_case'] >= 1
        assert parse_file(str(path)).get_symbols() == before
        assert not any('cobalt sentinel' in s for s in before)
    finally:
        manager.close()
