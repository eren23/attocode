"""One frozen callback-span candidate, evaluated through actual compact delivery."""
import argparse
import asyncio
import hashlib
import json
import re
import shutil
import sqlite3
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

import yaml
from attocode_intel._internal.integrations.context import semantic_search
from attocode_intel.focused_evidence import terms
from attocode_intel.gateway import OperationGateway
from candidate import extract_cases

from eval.quality.corpus import PACK, materialize, ready_search
from eval.quality.mcp_search import engine_identity

HERE = Path(__file__).resolve().parent


def explicit_test_intent(query):
    return bool(re.search(r'\btests?\b', query, re.I)) and len(terms(query)) <= 20


def gateway_for(gateways, arm, query):
    return gateways['candidate' if arm == 'candidate' and explicit_test_intent(query) else 'baseline']


def spans_for(root, original):
    root = Path(root).resolve()
    def spans(ast):
        symbols, classes = original(ast)
        path = Path(ast.path).resolve()
        cases = extract_cases(path.relative_to(root).as_posix(), path.read_text())
        symbols += [(c['start_line'], c['end_line'], 'test_case',
                     c['title'] + ' [' + c['id'][:12] + ']') for c in cases]
        return symbols, classes
    return spans


def index_evidence(root):
    with sqlite3.connect(Path(root) / '.attocode/index/kw_index.db') as conn:
        rows = conn.execute('SELECT * FROM kw_docs ORDER BY id').fetchall()
        keyword_sha256 = hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()
    with sqlite3.connect(Path(root) / '.attocode/index/kw_index.db') as conn:
        body_counts = dict(conn.execute('SELECT chunk_type,COUNT(*) FROM body_fts GROUP BY chunk_type'))
        test_units = conn.execute("SELECT file_path,name,start_line,end_line FROM body_fts WHERE chunk_type='test_case'").fetchall()
        named_windows = conn.execute("SELECT file_path,chunk_type,name,start_line,end_line,body FROM body_fts WHERE chunk_type IN ('function','method') ORDER BY file_path,chunk_type,name,start_line,end_line,body").fetchall()
    return {'keyword_sha256': keyword_sha256, 'keyword_documents': len(rows),
            'body_counts': body_counts, 'test_units': test_units,
            'function_method_windows_sha256': hashlib.sha256(json.dumps(named_windows).encode()).hexdigest()}


def delivered(response):
    decoded = json.loads(response.content[0].text)
    if response.isError:
        raise ValueError('MCP search failed: ' + str(decoded))
    return decoded


def judged(page, labels):
    hits = page['data'].get('results', [])
    files = {e['file'] for e in labels if any(h['file_path'] == e['file'] for h in hits)}
    def covers(file, span):
        for hit in hits:
            first, last = hit.get('snippet_start_line'), hit.get('snippet_end_line')
            if (hit['file_path'] != file or not isinstance(first, int) or not isinstance(last, int)
                    or first > span['line'] or last < span['end_line']):
                continue
            snippet, quote = hit.get('snippet', ''), span['quote']
            position = snippet.find(quote)
            while position >= 0:
                begin = first + snippet[:position].count('\n')
                end = first + snippet[:position + len(quote)].count('\n')
                if begin == span['line'] and end == span['end_line']:
                    return True
                position = snippet.find(quote, position + 1)
        return False
    excerpts = {e['file'] + ':' + str(e['assertion_line']) for e in labels
                if all(covers(e['file'], span) for span in e.get('required_excerpt_spans', [{
                    'quote': e['assertion_quote'], 'line': e['assertion_line'],
                    'end_line': e['assertion_end_line']}]))}
    return {'files': sorted(files), 'excerpts': sorted(excerpts)}


async def run(group, output):
    before = engine_identity()
    specs = yaml.safe_load(PACK.read_text())['repositories']
    spec = next(s for s in specs if s['id'] == group['pack'])
    assert spec['commit'] == group['commit']
    with tempfile.TemporaryDirectory(prefix='attocode-test-case-trial-') as temporary:
        work = Path(temporary)
        baseline_root, candidate_root, cache = (work / n for n in ('baseline', 'candidate', 'cache'))
        baseline_root.mkdir()
        cache.mkdir()
        tree = materialize(spec, baseline_root, cache)
        shutil.copytree(baseline_root, candidate_root, symlinks=True)
        for q in group['queries']:
            assert explicit_test_intent(q['query'])
            for e in q['evidence'] + q['implementation_evidence']:
                text = (baseline_root / e['file']).read_bytes()
                assert hashlib.sha256(text).hexdigest() == e['source_sha256']
                assert e['quote'] in text.decode()
        gateways = {a: OperationGateway(str(root), 'daily', watch=False)
                    for a, root in [('baseline', baseline_root), ('candidate', candidate_root)]}
        samples = []
        pages = []
        try:
            await ready_search(gateways['baseline'], {'query': 'warmup', 'top_k': 5, 'max_tokens': 2000})
            original = semantic_search._source_spans
            with patch.object(semantic_search, '_source_spans', spans_for(candidate_root, original)):
                await ready_search(gateways['candidate'], {'query': 'warmup', 'top_k': 5, 'max_tokens': 2000})
            representation = {arm: index_evidence(root) for arm, root in [('baseline', baseline_root), ('candidate', candidate_root)]}
            output.write_text(json.dumps({'status': 'representation_admission', 'pack': group['pack'],
                                          'representation': representation}))
            assert representation['baseline']['keyword_sha256'] == representation['candidate']['keyword_sha256']
            assert representation['candidate']['test_units'], 'Candidate callback units were not indexed'
            assert representation['candidate']['function_method_windows_sha256'] == representation['baseline']['function_method_windows_sha256']
            for repeat in range(3):
                for number, q in enumerate(group['queries']):
                    order = ['baseline', 'candidate'] if (number + repeat) % 2 == 0 else ['candidate', 'baseline']
                    for arm in order:
                        for depth, budget in [(5, 2000), (24, 8000)]:
                            started = time.perf_counter()
                            response = await gateway_for(gateways, arm, q['query']).execute_mcp('semantic_search', {
                                'query': q['query'], 'top_k': depth, 'max_tokens': budget})
                            elapsed = time.perf_counter() - started
                            page = delivered(response)
                            pages.append({'id': q['id'], 'arm': arm, 'round': repeat, 'depth': depth,
                                          'seconds': elapsed, 'judged': judged(page, q['evidence']), 'page': page})
                            samples.append({'arm': arm, 'seconds': elapsed})
                output.write_text(json.dumps({'status': 'running', 'pack': group['pack'], 'pages': pages}))
            # The candidate routes queries without explicit test intent through
            # the original index, including scoped searches. Check delivery.
            controls = []
            for query in ('find implementation', 'handle configuration', 'parse input'):
                assert not explicit_test_intent(query)
                args = {'query': query, 'top_k': 5, 'max_tokens': 2000}
                baseline = delivered(await gateways['baseline'].execute_mcp('semantic_search', args))
                routed = delivered(await gateway_for(gateways, 'candidate', query).execute_mcp('semantic_search', args))
                assert baseline['data'] == routed['data']
                controls.append({'query': query, 'unchanged': True,
                                 'baseline': baseline, 'candidate': routed})
        finally:
            for gateway in gateways.values():
                await gateway.close()
    assert before == engine_identity()
    output.write_text(json.dumps({'status': 'complete', 'pack': group['pack'], 'commit': group['commit'],
                                  'tree': tree, 'engine_sha256': before, 'pages': pages,
                                  'samples': samples, 'controls': controls,
                                  'representation': representation,
                                  'scratch_removed': not Path(temporary).exists()}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pack', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Refusing to overwrite results')
    questions = json.loads((HERE / 'questions.json').read_text())
    group = next(r for r in questions['repositories'] if r['pack'] == args.pack)
    asyncio.run(run(group, args.output))


if __name__ == '__main__':
    main()
