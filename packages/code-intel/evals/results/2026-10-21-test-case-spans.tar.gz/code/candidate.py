"""Frozen search-only callback spans; never changes navigation definitions."""
import hashlib
from pathlib import Path

from attocode_intel._internal.integrations.context.ts_parser import _get_parser, bounded_parse
from attocode_intel.test_ranking import is_test_path


def extract_cases(path, content):
    suffix = Path(path).suffix.lower()
    language = {'.js': 'javascript', '.mjs': 'javascript', '.cjs': 'javascript',
                '.jsx': 'javascript', '.ts': 'typescript', '.tsx': 'tsx'}.get(suffix)
    if not language or not is_test_path(path) or len(content.encode()) > 512 * 1024:
        return []
    parser = _get_parser(language)
    tree = bounded_parse(parser, content.encode()) if parser is not None else None
    if tree is None:
        return []
    stack = [tree.root_node]
    cases = []
    while stack and len(cases) < 1024:
        node = stack.pop()
        stack.extend(reversed(node.named_children))
        if node.type != 'call_expression' or node.has_error:
            continue
        fn = node.child_by_field_name('function')
        args = node.child_by_field_name('arguments')
        if fn is None or args is None:
            continue
        name = fn.text.decode()
        if fn.type == 'identifier':
            recognized = name in {'it', 'test'}
        elif fn.type == 'member_expression':
            obj = fn.child_by_field_name('object')
            prop = fn.child_by_field_name('property')
            recognized = (obj is not None and obj.type == 'identifier'
                          and obj.text in {b'it', b'test'} and prop is not None
                          and prop.text in {b'only', b'skip'})
        else:
            recognized = False
        arguments = [n for n in args.named_children if n.type != 'comment']
        if (not recognized or len(arguments) < 2 or arguments[0].type != 'string'
                or arguments[1].type not in {'arrow_function', 'function_expression'}):
            continue
        # Keep the literal spelling, including escapes; never evaluate JavaScript.
        title = arguments[0].text.decode()[1:-1]
        stable = f'{path}:{node.start_byte}:{node.end_byte}:{name}:{title}'
        cases.append({'id': hashlib.sha256(stable.encode()).hexdigest(),
                      'kind': 'test_case', 'title': title, 'form': name,
                      'start_line': node.start_point.row + 1,
                      'end_line': node.end_point.row + 1,
                      'start_column': node.start_point.column,
                      'end_column': node.end_point.column,
                      'text': node.text.decode()})
    return cases
