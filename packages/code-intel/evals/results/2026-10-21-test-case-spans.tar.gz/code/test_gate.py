import copy

import pytest
from compare import decide


def observations():
    questions = {'repositories': [{'pack': p, 'queries': [{'id': p + str(i)} for i in range(12)]}
                                  for p in ('express', 'prisma')]}
    reports = []
    for pack in ('express', 'prisma'):
        pages = []
        for i in range(12):
            for arm in ('baseline', 'candidate'):
                for round_ in range(3):
                    for depth in (5, 24):
                        files = ['new.js'] if i == 0 and arm == 'candidate' else []
                        if i == 1:
                            files = ['existing.js']
                        pages.append({'id': pack + str(i), 'arm': arm, 'round': round_, 'depth': depth,
                                      'seconds': .02, 'judged': {'files': files, 'excerpts': files}})
        reports.append({'pages': pages, 'scratch_removed': True, 'controls': [{'unchanged': True}]})
    return reports, questions


def test_no_loss_gate_rejects_one_displaced_excerpt_even_with_required_gains():
    reports, questions = observations()
    assert decide(reports, questions)['status'] == 'accepted'
    broken = copy.deepcopy(reports)
    next(p for p in broken[0]['pages'] if p['id'] == 'express1' and p['arm'] == 'candidate')['judged']['excerpts'] = []
    result = decide(broken, questions)
    assert result['status'] == 'rejected'
    assert result['checks']['two_new_first_page_matches_every_round']
    assert not result['checks']['no_file_or_excerpt_loss']


def test_gate_requires_both_repositories_and_latency_in_each_round():
    reports, questions = observations()
    for page in reports[1]['pages']:
        if page['id'] == 'prisma0' and page['arm'] == 'candidate' and page['round'] == 2:
            page['judged']['files'] = []
        if page['arm'] == 'candidate' and page['round'] == 1:
            page['seconds'] = .051
    checks = decide(reports, questions)['checks']
    assert not checks['gains_in_both_repositories_every_round']
    assert not checks['warm_p95_each_round']


def test_gate_rejects_duplicate_or_missing_observations():
    reports, questions = observations()
    reports[0]['pages'].pop()
    with pytest.raises(AssertionError):
        decide(reports, questions)
