import pytest
from candidate import extract_cases


def test_case_boundaries_are_literal_and_search_only():
    source = '''describe('group', () => {
  it('handles missing values', () => {
    expect(read(null)).toBe(null);
  });
  test.only("keeps unicode π", async () => { await check(); });
  it.skip('known failure', function () { check(); });
});
'''
    cases = extract_cases('test/sample.test.ts', source)
    assert [(c['title'], c['start_line'], c['end_line']) for c in cases] == [
        ('handles missing values', 2, 4), ('keeps unicode π', 5, 5), ('known failure', 6, 6)]
    assert cases == extract_cases('test/sample.test.ts', source)
    assert len({c['id'] for c in cases}) == 3
    assert all(c['kind'] == 'test_case' for c in cases)
    assert 'expect(read(null)).toBe(null);' in cases[0]['text']


@pytest.mark.parametrize('source', [
    "other.it('title', () => check());", "it(title, () => check());",
    "it(`value ${name}`, () => check());", "it('title', callback);",
    "test.each(values)('title', () => check());", "describe('title', () => check());",
    "it.only.skip('title', () => check());", "test('title', 42);",
])
def test_dynamic_and_unrecognized_dsls_are_not_inferred(source):
    assert extract_cases('test/sample.js', source) == []


def test_identical_titles_have_distinct_stable_coordinates():
    cases = extract_cases('tests/a.js', "it('same', () => first()); it('same', () => second());")
    assert len(cases) == len({c['id'] for c in cases}) == 2
    assert cases[0]['start_column'] != cases[1]['start_column']


def test_other_language_is_unchanged():
    assert extract_cases('tests/a.py', "it('title', lambda: 1)") == []
