from trial import judged


def test_matching_text_at_wrong_source_coordinates_is_not_excerpt_evidence():
    labels = [{'file': 'test/a.js', 'assertion_line': 10, 'assertion_end_line': 11,
               'assertion_quote': 'expect(value)\n .toBe(1)'}]
    hit = {'file_path': 'test/a.js', 'snippet': 'setup\nexpect(value)\n .toBe(1)', 'line': 20, 'end_line': 30,
           'snippet_start_line': 20, 'snippet_end_line': 30}
    assert judged({'data': {'results': [hit]}}, labels) == {'files': ['test/a.js'], 'excerpts': []}
    hit.update(line=9, end_line=11, snippet_start_line=9, snippet_end_line=11)
    assert judged({'data': {'results': [hit]}}, labels)['excerpts'] == ['test/a.js:10']
    hit.update(line=9, end_line=10, snippet_start_line=9, snippet_end_line=10)
    assert judged({'data': {'results': [hit]}}, labels)['excerpts'] == []


def test_input_and_output_context_are_both_required_even_in_separate_windows():
    evidence = [{'file': 'test/a.js', 'assertion_line': 40, 'assertion_end_line': 41,
                 'assertion_quote': 'output\nexpected', 'required_excerpt_spans': [
                     {'line': 3, 'end_line': 4, 'quote': 'input\noriginal'},
                     {'line': 40, 'end_line': 41, 'quote': 'output\nexpected'}]}]
    hits = [{'file_path': 'test/a.js', 'snippet': 'setup\noutput\nexpected', 'line': 39, 'end_line': 42,
             'snippet_start_line': 39, 'snippet_end_line': 42}]
    assert judged({'data': {'results': hits}}, evidence)['excerpts'] == []
    hits.append({'file_path': 'test/a.js', 'snippet': 'one\ntwo\ninput\noriginal', 'line': 1, 'end_line': 6,
                 'snippet_start_line': 1, 'snippet_end_line': 6})
    assert judged({'data': {'results': hits}}, evidence)['excerpts'] == ['test/a.js:40']


def test_original_chunk_coordinates_do_not_bless_a_repeated_quote_outside_snippet():
    evidence = [{'file': 'test/a.js', 'assertion_line': 10, 'assertion_end_line': 10,
                 'assertion_quote': 'expect(value).toBe(1)'}]
    hit = {'file_path': 'test/a.js', 'line': 1, 'end_line': 100,
           'snippet_start_line': 40, 'snippet_end_line': 40, 'snippet': 'expect(value).toBe(1)'}
    assert judged({'data': {'results': [hit]}}, evidence)['excerpts'] == []
