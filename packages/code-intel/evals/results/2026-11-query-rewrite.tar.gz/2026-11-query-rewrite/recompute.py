"""Standard-library recompute of the partial development screen (run 41317095737).

Usage: python3 recompute.py DESIGN.json
Applies the rule in precommit.md: a gate decides only if it fails for every outcome of the
packs that did not run. Prints partial-decision JSON and asserts the three certain failures.
"""
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUN = HERE / "run-41317095737" / "obs"
PAGES = ("5", "24", "scoped")

design_bytes = Path(sys.argv[1]).read_bytes()
design = json.loads(design_bytes)
digest = hashlib.sha256(design_bytes).hexdigest()
planned_questions = sum(len(g["queries"]) for g in design["repositories"])
planned_rewrites = planned_questions * len(PAGES) * 3
planned_searches = planned_questions * 2 * 3

packs = sorted(p.stem for p in (RUN / "candidate").glob("*.json"))
base = {p: json.loads((RUN / "baseline" / f"{p}.json").read_text()) for p in packs}
cand = {p: json.loads((RUN / "candidate" / f"{p}.json").read_text()) for p in packs}
runs = [*base.values(), *cand.values()]
assert all(r["questions_sha256"] == digest for r in runs)
assert len({(r["operator_sha256"], r["engine_sha256"]) for r in runs}) == 1
assert all(r["rerank_calls"] == {"posted": 0, "refused": 0} for r in runs)
assert all(r["rewrite_calls"] == {"posted": 0, "refused": 0} for r in base.values())

losses, net, totals = [], {}, Counter()
rewrites, searches = [], []
for pack in packs:
    new = {row["id"]: row for row in cand[pack]["queries"]}
    assert set(new) == {row["id"] for row in base[pack]["queries"]}
    for old in base[pack]["queries"]:
        row = new[old["id"]]
        for page in PAGES:
            p = row["pages"][page]
            assert len(p["samples"]) == 3
            for metric, labels in p["hits"].items():  # worst of three samples
                assert sorted(set.intersection(*(set(s["hits"][metric]) for s in p["samples"]))) == labels
            for s in p["samples"]:
                assert len(s["rewrite_diagnostic"]) == 1
                rewrites.extend(s["rewrite_diagnostic"])
                if page != "scoped":
                    searches.append(s["seconds"])
            for metric in ("files", "visible"):
                totals[f"baseline_{metric}_{page}"] += len(old["pages"][page]["hits"][metric])
                totals[f"candidate_{metric}_{page}"] += len(p["hits"][metric])
                missing = sorted(set(old["pages"][page]["hits"][metric]) - set(p["hits"][metric]))
                if missing:
                    losses.append({"id": old["id"], "page": page, "metric": metric, "labels": missing})
        net[pack] = net.get(pack, 0) + len(row["pages"]["5"]["hits"]["files"]) - len(old["pages"]["5"]["hits"]["files"])

statuses = Counter(d["status"] for d in rewrites)
fallbacks = len(rewrites) - statuses["ok"]
file_loss = {pg: sum(len(x["labels"]) for x in losses if x["page"] == pg and x["metric"] == "files") for pg in ("5", "24")}
certain = {
    "no_file_loss_24": file_loss["24"] > 0,
    "at_most_one_file_loss_5": file_loss["5"] > 1,
    "scoped_no_individual_loss": any(x["page"] == "scoped" for x in losses),
    "fallback_rate": fallbacks > .05 * planned_rewrites,
    "rewrite_p95": sum(d["elapsed_ms"] > 1500 for d in rewrites) > .05 * planned_rewrites,
    "search_p95": sum(s > 2.0 for s in searches) > .05 * planned_searches,
}
result = {
    "design_sha256": digest, "completed_packs": packs, "planned_questions": planned_questions,
    "completed_questions": sum(len(r["queries"]) for r in cand.values()),
    "planned_rewrites": planned_rewrites, "recorded_rewrites": len(rewrites),
    "statuses": dict(statuses), "fallbacks": fallbacks,
    "rewrites_over_1500_ms": sum(d["elapsed_ms"] > 1500 for d in rewrites),
    "searches_over_2_s": sum(s > 2.0 for s in searches),
    "files_5_net_by_pack": net, "file_label_losses": file_loss,
    "individual_losses": losses, "totals": dict(sorted(totals.items())),
    "posted_calls": {p: cand[p]["rewrite_calls"]["posted"] for p in packs},
    "gates_failed_for_every_missing_outcome": [g for g, failed in certain.items() if failed],
}
assert result["gates_failed_for_every_missing_outcome"] == [
    "no_file_loss_24", "scoped_no_individual_loss", "fallback_rate"]
print(json.dumps(result, indent=2))
