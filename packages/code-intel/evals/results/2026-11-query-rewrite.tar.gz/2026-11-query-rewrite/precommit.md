Written before reading any candidate row of run 41317095737 (2026-11-01).
The run is incomplete: candidate rows exist for express and ripgrep only; cats-effect failed the preflight.
Rule: the development screen has a verdict only if a frozen gate fails for every possible outcome of the
8 missing packs. Gates checked this way: no_file_loss_24 (any loss), at_most_one_file_loss_5 (>1 loss),
compare() checks that fail on any change, fallback_rate (fallbacks > 5% of all 612 planned rewrites),
rewrite_p95 (more than 5% of 612 rewrites above 1500 ms), search_p95 (same with 2.0 s over 408 searches).
If no gate fails for certain, the dev screen is INCOMPLETE, no verdict.
