"""Saved-evidence replay only; no product code, native parsing or network."""
import hashlib, io, json, pathlib, xml.etree.ElementTree as ET, zipfile
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected, name
encode=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
for n in [1,2]:
    with zipfile.ZipFile(io.BytesIO((root/f'attempt-{n}/runner-artifact.zip').read_bytes())) as z:
        d=json.loads(z.read('decision.json'))
        assert d['status']=='incomplete' and d['decision'] is None
        assert d['cleanup_verified'] and d['identities_unchanged'] and d['budget_violation'] is None
        assert len(d['trials'])==n-1
        if n==1:
            assert not d['trials']
            continue
        p={k:json.loads(z.read(f'baseline-0-{k}.json')) for k in ['cold','restart']}
        assert p['cold']['pid']!=p['restart']['pid']
        for record in p.values():
            assert record['status']=='passed'
            assert hashlib.sha256(encode(record['evidence'])).hexdigest()==record['evidence_sha256']
            assert hashlib.sha256(z.read(record['journal'])).hexdigest()==record['journal_sha256']
        assert len(p['cold']['evidence'])==len(p['restart']['evidence'])==10
        assert [k for k in p['cold']['evidence'] if p['cold']['evidence'][k]!=p['restart']['evidence'][k]]==['definition']
        sets=[set(map(encode,p[k]['evidence']['definition'])) for k in ['cold','restart']]
        assert all(len(s)==30 for s in sets) and len(sets[0]&sets[1])==23
        assert all(json.loads(row)['score']==.53 for row in sets[0]^sets[1])
        for arm, count, failures in [('baseline',1,1),('candidate',67,0)]:
            cases=ET.fromstring(z.read(arm+'-tests.xml')).findall('.//testcase')
            assert len(cases)==count and sum(c.find('failure') is not None for c in cases)==failures
            assert not any(c.find('error') is not None or c.find('skipped') is not None for c in cases)
print(json.dumps({'status':'incomplete','performance_verdict':None,'candidate_trials':0,'baseline_phases':2,'other_operations_equal':9,'definition_common':23,'definition_each':30}))
