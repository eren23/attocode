# Optional Language Coverage Implementation Plan
> For agentic workers: execute inline with superpowers:executing-plans; one fresh whole-branch reviewer on mostcapablemodel. Private persistent ledger authoritative.
**Goal:** Verify narrowly configured Perl and improve evidenced Crystal/OCaml/Perl native definition/call/import workflows.
**Architecture:** explicit pinnedgrammar setup in GHA, deterministic native fixtures, source-aware minimal language fixes after causal RED, maintained optional native CI admission.
**Tech Stack:** Python/tree-sitter/pathspec/GHA/stdlibretaineddata. **Spec:** spec.md. **BASE:**d83e109898d5e86a215852683ff202bdfa432ae0.
## Global Constraints
All actualruntime/tests/build/install/native/fixtures ONLINEGHAONLY; localstatic/private stdlibretaineddataonly. PreserveDocker/globaltools/MCP/history/AGENTS/privateproof. No globalupgrade/MCP restart/new relevance claim/oldfixtureedit. Native100ms unchanged; qualification600s/2GiBRSSdisk/64MiB, setup5min; existingrelease019immutable. Inline/in-place/privateplans/standingauthority.
## Review Focus
Scoped inclusion must not admit unrelated generatedpaths; removing override must invalidate symbols. Actual native optional grammar required on dedicatedCI, optout skip is never positiveproof. Calls exclude declarations/comments/strings and preserve source spans. Imports resolve only within source workspace, preserve ambiguity and source identity. Original36pack/144question truth remains immutable; no new causal/performance claims.
## Task1 Causal native baseline and existing inclusion coverage
Files tests/test_source_exclusions.py (one newcoreguard), tests/test_optional_language_depth.py (8nativecases); temp eval/quality/language_depth_experiment.py, experiments/languagedepth.json, experiments.py/workflow choice/setup; privatecollectors.
Consumes currentnativepipeline and explicitCrystalpin; produces originalbaseline XML/rawAST/MCP/source/grammar receipt.
- [x] Write private spec/plan and realnative+coretests before product changes; preserveexistingtest.
- [ ] Freeze baseline/setup/allowednewassertions; onlinebaseline expect383cases(375old+8new), noerrors/skips, knownCrystalmethod/classRED, allold375positive. Admit original/source/origins/caps/cleanup before product patch.
## Task2 Minimal corrections and pairedGREEN
Files product ts_parser.py/syntax_evidence.py/codebase_context.py only as actual native AST warrants; tests above may gain meaningful safety boundaries from findings.
Consumes Task1causalnativefailures and rawAST; produces native defs/calls/withinroot imports preserving qualifiers.
- [ ] Implement only demonstrated failure mechanisms; realnativecalls once/no acquires/retries/timeouts changed. Scopedignore behavior uses existingmechanism, no global loosening.
- [ ] OnlineGREEN allcases unskipped, semantic/rawsource/grammar/MCP replay and negativeguards; retain original failures.
## Task3 Maintain, review, integrate
Files optionalgrammar acquisition script/workflow, optionalJUnit receipt, maintainedpreflight375/required388/broadplatform375; report/docs/archive.
Consumes nativeGREEN; produces permanent8nativegate+coreguards and truthful report.
- [ ] Archive all originalZIPs/fullsources; retire tempoperator/design/choice; retain pinnedexplicitsetup+native8 and all priorcontrols; scope/countsourceverify.
- [ ] Freshwholebranchreview, onecausalfixpass ifimportant, then all17normalCI+7families/388required/SQL51each/real4/install17/preflight375/image+optionalnative8/unskipped.
- [ ] Exactmerge/sync trees/3postgreen/leasedcleanup/019immutable/repo0/observers/notes; record unreleased product state and proceed separateversioned020release only through fullgates.
## Ledger
Pre-flight: Task1 actualnativeproof feeds Task2; Task2 allGREEN feeds Task3 maintainedCI. Newnative cases stay outside defaultpreflight so absent optional packages cannot silently skip mandatory375controls. Task1 baseline allows only new assertion failures, not unexpected errors. Explicituseroptout preserves privateplans/in-place/no menus; no local setup/test commands from generic skills apply.

Nativebaseline40843508338 at0063b83 launchedonceafterstaticRuff/diff/sourceguard. ALL349runtimeBASEexact. eightnewnativecases andtwoexclusioncases declared383total. Mustcollect/admit beforeproductedit. Userprefsexistingexplicitinclusionacknowledged; no fakeproductbugclaimed.
