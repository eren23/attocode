"""Independent authored-fixture/native-MCP replay; private stdlib data only."""
import ast,hashlib,json
from pathlib import Path

def replay(native, test_source):
    native=Path(native);module=ast.parse(test_source);result={};roots=set()
    for lang in ('ocaml','perl','crystal'):
        function=next(n for n in module.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='test_'+lang+'_cross_file_workflow')
        call=next(n for n in ast.walk(function) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='workflow')
        files,spec=ast.literal_eval(call.args[1]),ast.literal_eval(call.args[2]);spec.update(source_sha256=hashlib.sha256(files[spec['file']].encode()).hexdigest(),queries=[])
        inputs=json.loads((native/(lang+'-workflow-inputs.json')).read_bytes());assert inputs['files']==files and inputs['spec']==spec;root=inputs['root'];assert root not in roots and root.startswith('/');roots.add(root)
        folder=native/(lang+'-workflow');responses=[];closed=set();last={}
        for line in (folder/'events.jsonl').read_bytes().splitlines():
            event=json.loads(line);ref=event['response'];blob=(folder/ref['path']).read_bytes();assert len(blob)==ref['bytes'] and hashlib.sha256(blob).hexdigest()==ref['sha256'];request=event['request'];value=json.loads(blob)
            if request['event']=='mcp_response':
                assert not value['isError'];page=json.loads(value['content'][0]['text']);assert page['metadata']['workspace']==root
                gateway=request['gateway'];seq=request['sequence'];assert seq==last.get(gateway,-1)+1;last[gateway]=seq
                assert request['arguments']['max_tokens']==4000
                responses.append((request,page['data']))
            elif request['event']=='gateway_close':
                assert value=={'status':'complete'} and request['gateway'] not in closed;closed.add(request['gateway'])
        assert closed=={0,1}
        raw_count=len(responses);warming=[];logical=[]
        for at,(request,data) in enumerate(responses):
            if request['tool']=='semantic_search' and data.get('ranking',{}).get('index',{}).get('status')=='warming':
                assert at+1<len(responses) and responses[at+1][0]['tool']=='semantic_search'
                assert request['arguments']==responses[at+1][0]['arguments']
                warming.append(at)
            else:
                logical.append((request,data))
        responses=logical
        assert len(responses)==8
        expected=['search_symbols','inspect_symbol','semantic_search','cross_references','dependencies','impact_analysis','suggest_tests','inspect_symbol'];assert [r['tool'] for r,d in responses]==expected
        def definition(item):return item['file_path']==spec['file'] and item['name'].replace('::','.').split('.')[-1]==spec['symbol']
        assert any(definition(row) for row in responses[0][1])
        for at in (1,7):
            data=responses[at][1];assert data['status']=='found' and definition(data['definition'])
            for excerpt in [data.get('source',{}),*data.get('source_excerpts',[])]:
                if excerpt.get('text'):
                    name=excerpt.get('file_path',spec['file']);lines=files[name].splitlines();assert excerpt['text']=='\n'.join(lines[excerpt['start_line']-1:excerpt['end_line']])
        hits=responses[2][1]['results'];assert hits and all(h['file_path']==spec['file'] for h in hits)
        for h in hits:
            if h.get('snippet'):
                lines=files[spec['file']].splitlines(keepends=True);window=''.join(lines[h['snippet_start_line']-1:h['snippet_end_line']]);assert h['snippet'] in window
        refs=responses[3][1];actual={(r['file_path'],r['line']) for r in refs['references']};expected_calls={(name,next(i for i,line in enumerate(files[name].splitlines(),1) if spec['symbol'] in line)) for name in (spec['caller'],spec['test'])}
        assert actual==expected_calls and len(refs['references'])==refs['total_references']==2
        assert all(r['ref_kind']=='call' and r['source']=='tree-sitter' and r['symbol']==spec['symbol'] for r in refs['references'])
        assert set(responses[4][1]['imported_by'])=={spec['caller'],spec['test']}
        impact=responses[5][1];assert not impact.get('absence_proven',False);affected=set(impact.get('impacted_files',[]))|{p for layer in impact.get('layers',[]) for p in layer['files']};assert spec['caller'] in affected
        tests=responses[6][1];assert not tests.get('absence_proven',False) and any(c['file_path']==spec['test'] for c in tests['candidates'])
        checks=json.loads((native/(lang+'-workflow-checks.json')).read_bytes());assert len(checks)==8 and all(c['outcome']=='passed' for c in checks)
        assert checks[2]['warming_responses']==len(warming) and checks[2]['warmup_seconds']<=90
        result[lang]={'checks':8,'raw_responses':raw_count,'warming_responses':len(warming),'syntax_calls':2,'importers':2,'source_workspace_routes_verified':True,'test_evidence':'heuristic/import candidates, not semantic proof'}
    for lang,target in [('ocaml','Helper.greet'),('perl','Lib.Helper.greet')]:
        assert json.loads((native/(lang+'-calls.json')).read_bytes())==[[target,'call',2]]
    return result
