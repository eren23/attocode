"""Independent qualified native GREEN admission, no tested imports/execution."""
import hashlib,json,subprocess,sys
from pathlib import Path
from depth_data import replay
R=Path(__file__).parent;A=R/'review-green-1';p=json.loads((A/'admission.json').read_bytes());assert p['outcome']=='passed' and p['xml'][0]['cases']==p['xml'][0]['passed']==406
head=p['run']['head_sha'];source=subprocess.check_output(['git','show',head+':packages/code-intel/tests/test_optional_language_depth.py']);e=next(A.rglob('languagedepth-control-verdict.json')).parent
workflows=replay(e/'native-depth',source);old=next((R/'imports-baseline-1').rglob('languagedepth-control-verdict.json')).parent/'native-depth'
for name in ('ocaml-calls-native.json','perl-calls-native.json','ocaml-imports-native.json','perl-imports-native.json','crystal-imports-native.json'):
 before=json.loads((old/name).read_bytes());after=json.loads((e/'native-depth'/name).read_bytes());assert before['tree']==after['tree'] and before['source']==after['source'] and before['sha256']==after['sha256']
proof={'outcome':'passed','head':head,'run':p['run']['id'],'cases':406,'maintained':384,'dedicated_depth':22,'authored_workflows':workflows,'raw_mcp_responses':sum(v['raw_responses'] for v in workflows.values()),'native_tree_inputs_equal_before_after':True,'grammar_before_after_source_bound':True,'operator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'replay_sha256':hashlib.sha256((R/'depth_data.py').read_bytes()).hexdigest(),'local_tested_execution':False};(R/'review-green-1-semantic-admission.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
