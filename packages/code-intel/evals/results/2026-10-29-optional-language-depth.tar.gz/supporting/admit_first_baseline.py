"""Admit observations from a FAILED baseline, without relabeling its verdict."""
import hashlib,json,pathlib,subprocess,xml.etree.ElementTree as E,zipfile
R=pathlib.Path(__file__).parent;A=R/'baseline-1';p=json.loads((A/'admission.json').read_bytes());assert p['outcome']=='retained-incomplete' and p['run']['conclusion']=='failure' and p['run']['run_attempt']==1
raw=(A/'artifact.zip').read_bytes();assert hashlib.sha256(raw).hexdigest()==p['archive_sha256']
with zipfile.ZipFile(A/'artifact.zip') as z:
 for item in z.infolist():
  if not item.is_dir():assert (A/item.filename).read_bytes()==z.read(item)
r=p['report'];assert r['identity']['commit']==p['run']['head_sha'];sup=r['supervision'];assert sup['exit_code']==1 and sup['status']=='failed' and not sup['log_truncated'] and sup['cleanup_verified'] and r['owned_scratch_removed'] and r['cleanup_verified'];assert r['seconds']<600 and sup['peak_rss_bytes']<2**31 and sup['peak_disk_bytes']<2**31 and sup['peak_evidence_bytes']<63*2**20
head=p['run']['head_sha']
for name,sha in r['identity']['files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+name])).hexdigest()==sha
assert not subprocess.check_output(['git','diff','d83e109898d5e86a215852683ff202bdfa432ae0',head,'--','packages/code-intel/src','packages/code-intel/pyproject.toml','uv.lock'])
e=next(A.rglob('languagedepth-controls.xml')).parent;cases=list(E.fromstring((e/'languagedepth-controls.xml').read_bytes()).iter('testcase'));assert len(cases)==383 and not any(c.find('error') is not None or c.find('skipped') is not None for c in cases)
failed={c.get('name'):c for c in cases if c.find('failure') is not None};expected={'test_ocaml_native_call_candidates_exclude_decoys','test_perl_native_call_candidates_exclude_decoys','test_ocaml_cross_file_workflow','test_perl_cross_file_workflow','test_crystal_cross_file_workflow'};assert set(failed)==expected
assert all(c.get('classname').endswith('test_optional_language_depth') for c in failed.values())
assert all(c.find('failure') is None for c in cases if not c.get('classname').endswith('test_optional_language_depth'))
for name,c in failed.items():
 text=''.join(c.find('failure').itertext())
 if name.endswith('exclude_decoys'):assert 'AssertionError: language coverage:' in text
 else:assert 'ValueError: failed compatibility check: '+('dependencies' if name.startswith('test_crystal') else 'caller_syntax') in text
before=json.loads((e/'grammar-before.json').read_bytes());after=json.loads((e/'grammar-after.json').read_bytes());assert before==after and before['direct_url']['vcs_info']['commit_id']=='50ca9e6fcfb16a2cbcad59203cfd8ad650e25c49'
for events in e.rglob('events.jsonl'):
 for line in events.read_bytes().splitlines():
  event=json.loads(line);ref=event['response'];data=(events.parent/ref['path']).read_bytes();assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256']
proof={'status':'verified-failed-baseline-observations','original_verdict_unchanged':'retained-incomplete','run':p['run']['id'],'head':head,'archive_sha256':p['archive_sha256'],'cases':383,'passed':378,'old_controls_passed':375,'failed':sorted(expected),'no_errors_or_skips':True,'native_setup_source_grammar_inputs_raw_limits_cleanup_verified':True,'finding':'Crystal native definitions already pass; planned mandatory Crystal failures were wrong. Actual5failures are2nativecall omissions+2caller workflows+Crystal dependencies. No product change yet.'};(R/'baseline-1-causal-evidence.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
