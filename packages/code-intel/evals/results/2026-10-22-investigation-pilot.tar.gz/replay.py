"""Verify sanitized pilot accounting/structure. No model calls or semantic grading."""
import hashlib
import json
from pathlib import Path
from decimal import Decimal


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'SHA256SUMS.json').read_text())
    assert set(manifest) == {'observations.json', 'protocol.json', 'replay.py'}
    for name, expected in manifest.items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
    data = json.loads((root / 'observations.json').read_text())
    protocols = json.loads((root / 'protocol.json').read_text())
    rows = data['attempts']
    assert len(rows) == 4 and len({r['id'] for r in rows}) == 4
    scored = [r for r in rows if not r['excluded_wiring']]
    wiring = [r for r in rows if r['excluded_wiring']]
    assert len(scored) == data['observed_scored_attempts'] == 2
    assert len(wiring) == data['excluded_wiring_attempts'] == 2
    assert all(r['status'] == 'completed' for r in wiring)
    assert all(r['status'] == 'incomplete' and r['task_id'] == 'I07' for r in scored)
    assert data['planned_scored_attempts'] - len(scored) == data['unlaunched_scored_attempts'] == 14
    assert all(r['cleanup_verified'] for r in rows) and data['controller']['scratch_cleanup_verified']
    assert sum(r['cost_usd'] is None for r in rows) == 1
    known = sum(Decimal(str(r['cost_usd'])) for r in rows if r['cost_usd'] is not None)
    assert abs(known - Decimal(data['known_reported_cost_subtotal_usd'])) < Decimal('1e-14')
    assert Decimal(data['known_reported_cost_subtotal_usd']) == Decimal('0.1823414')
    assert all(data[k] is None for k in ['total_reported_cost_usd', 'cost_ratio', 'time_ratio', 'fully_correct_delta', 'semantic_grades'])
    assert data['status'] == data['controller']['status'] == 'incomplete'
    assert data['stop']['no_retry_or_replacement'] and data['no_agent_benefit_claim']
    assert data['frozen_identities_verified_after_run']
    allowed = {'Read', 'Grep', 'Glob', 'StructuredOutput'}
    required = {'task_id', 'implementation', 'caller', 'regression_test', 'negative_control', 'uncertainties'}
    for name, trace in protocols.items():
        assert trace['client_version'] == '2.1.287' and trace['model'] == 'claude-sonnet-5-5'
        assert len(trace['terminal_results']) == (0 if name == 'I07-native' else 1)
        for call in trace['calls']:
            if call['name'] != 'StructuredOutput':
                continue
            shape = call['arguments_shape']
            props = shape['properties']
            structurally_valid = (set(props) == required
                                  and all(props[k]['type'] == 'object' for k in ['implementation', 'caller', 'regression_test', 'negative_control'])
                                  and props['uncertainties']['type'] == 'array')
            assert structurally_valid == call['serialization_schema_valid']
    intel = protocols['I07-intel']
    native = protocols['I07-native']
    assert [c['serialization_schema_valid'] for c in intel['calls'] if c['name'] == 'StructuredOutput'] == [False, True]
    assert [c['serialization_schema_valid'] for c in native['calls'] if c['name'] == 'StructuredOutput'] == [False]
    unknown = [c for c in native['calls'] if c['name'] not in allowed]
    assert [c['name'] for c in unknown] == ['caller', 'regression_test', 'negative_control', 'uncertainties']
    assert all(c['result']['is_error'] for c in unknown)
    assert not any(c['name'].startswith('mcp__') for c in intel['calls'])
    assert next(r for r in scored if r['arm'] == 'intel')['final_answer_schema_and_quotes_valid']
    print(json.dumps({'status': 'incomplete', 'scored_attempts': 2, 'excluded_wiring': 2,
                      'known_reported_cost_subtotal_usd': data['known_reported_cost_subtotal_usd'], 'ratios': None,
                      'fully_correct_delta': None, 'replay': 'accounting_and_structural_protocol_only'}))


if __name__ == '__main__':
    main()
