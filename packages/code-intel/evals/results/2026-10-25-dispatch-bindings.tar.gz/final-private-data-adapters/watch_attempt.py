"""Metadata-only observer for an existing pinned manual attempt; never dispatches."""
import json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).parent
ident=int(sys.argv[1]);head=sys.argv[2];label=sys.argv[3];start=time.monotonic();previous=None
(root/(label+'-watch-owner.json')).write_text(json.dumps({'pid':os.getpid(),'run':ident,'head':head})+'\n')
while time.monotonic()-start<2400:
 r=json.loads(subprocess.check_output(['gh','api',f'repos/eren23/attocode/actions/runs/{ident}'],timeout=45))
 assert r['head_sha']==head and type(r['run_attempt'])is int and r['run_attempt']==1 and r['event']=='workflow_dispatch' and r['path']=='.github/workflows/intelligence-experiments.yml'
 jobs=json.loads(subprocess.check_output(['gh','api',f'repos/eren23/attocode/actions/runs/{ident}/jobs?per_page=100'],timeout=45))['jobs']
 state={'status':r['status'],'conclusion':r['conclusion'],'jobs':[{k:j[k] for k in ('name','status','conclusion')} for j in jobs]}
 (root/(label+'-watch-latest.json')).write_text(json.dumps({'run':r,'jobs':jobs,'observed_unix':time.time()},indent=2)+'\n')
 if state!=previous:print(json.dumps(state),flush=True);previous=state
 if r['status']=='completed':
  assert len(jobs)==1 and all(j['status']=='completed' for j in jobs)
  print('EXISTING_TRIAL_WORKFLOW_COMPLETED',flush=True);break
 time.sleep(30)
else:raise TimeoutError('Existing trial metadata incomplete; no rerun')
