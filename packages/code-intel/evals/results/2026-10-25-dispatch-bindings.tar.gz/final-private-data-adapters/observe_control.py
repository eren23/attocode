"""Observe/admit one retained dispatch receipt; never dispatch or rerun."""
import json,pathlib,subprocess,sys
r=pathlib.Path(__file__).parent;label=sys.argv[1];d=json.loads((r/(label+'-dispatch.json')).read_bytes())['run']
with (r/(label+'-watch.log')).open('w') as stream:
 subprocess.run([sys.executable,str(r/'watch_attempt.py'),str(d['id']),d['head_sha'],label],stdout=stream,stderr=subprocess.STDOUT,check=True)
with (r/(label+'-collect.log')).open('w') as stream:
 subprocess.run([sys.executable,str(r/'collect_controls.py'),str(d['id']),d['head_sha'],'dispatch',str(r/label)],stdout=stream,stderr=subprocess.STDOUT,check=True)
proof=json.loads((r/label/'admission.json').read_bytes());assert proof['outcome']=='passed',proof['outcome']
print(label,'ADMITTED',d['id'],d['head_sha'],flush=True)
