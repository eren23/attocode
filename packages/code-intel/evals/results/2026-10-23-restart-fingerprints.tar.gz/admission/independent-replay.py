"""Independent retained-data replay; no product/operator imports or runtime tests."""
import ast
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ATTEMPT = ROOT / 'restart-attempt-1'
EVIDENCE = ATTEMPT / 'intelligence-experiment-39893315367-1/evidence/restart'
PROOF = json.loads((ATTEMPT / 'admission.json').read_bytes())
HEAD = '498599b429d60f45bfc189457901227ddce313fc'
assert PROOF['run']['head_sha'] == HEAD and PROOF['report']['status'] == 'incomplete'
assert PROOF['report']['cleanup_verified'] and PROOF['report']['owned_scratch_removed']


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def load(journal, ref):
    assert ref['path'] == f'blobs/{ref["sha256"]}.json'
    raw = (journal / ref['path']).read_bytes()
    assert len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256']
    return json.loads(raw)


freeze = json.loads((EVIDENCE / 'freeze.json').read_bytes())
assert freeze['baseline'] == 'cc0b52dee916d94359473f3bd3b082ab73ed87f0' and freeze['head'] == HEAD
manifest = load(EVIDENCE / 'journal', freeze['fixture_ref'])
spec = json.loads((EVIDENCE / 'spec.json').read_bytes())
assert spec['commit'] == '53aadff3cedde4d810c72b69ddd96e6a735d93e7'
clone = Path('/Users/eren/Documents/ai/benchmark-repos/cockroach')
listing = subprocess.check_output(['git', '-C', str(clone), 'ls-tree', '-r', '-l', '-z', spec['commit'], '--', *spec['include']])
skip = {}
source = subprocess.check_output(['git', 'show', HEAD + ':packages/code-intel/src/attocode_intel/_internal/integrations/context/codebase_context.py'])
for n in ast.parse(source).body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in {'SKIP_EXTENSIONS', 'SKIP_FILENAMES'}:
        skip[n.targets[0].id] = ast.literal_eval(n.value)
entries = {}
for record in listing.split(b'\0'):
    if not record:
        continue
    meta, name = record.split(b'\t', 1)
    mode, kind, oid, size = meta.decode().split()
    name = os.fsdecode(name)
    if mode == '120000' or (mode in {'100644', '100755'} and 0 <= int(size) <= 1000000
            and Path(name).suffix.lower() not in skip['SKIP_EXTENSIONS'] and Path(name).name not in skip['SKIP_FILENAMES']):
        entries[name] = mode, oid, int(size)
assert set(entries) == set(manifest) and len(entries) == 9758
oids = sorted({r[1] for r in entries.values()})
raw = subprocess.check_output(['git', '-C', str(clone), 'cat-file', '--batch'], input=''.join(o + '\n' for o in oids).encode())
blobs, at = {}, 0
while at < len(raw):
    end = raw.index(b'\n', at)
    oid, kind, size = raw[at:end].decode().split()
    body = raw[end + 1:end + 1 + int(size)]
    assert kind == 'blob' and hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == oid
    blobs[oid] = body
    at = end + 1 + int(size) + 1
for name, (mode, oid, size) in entries.items():
    body = blobs[oid]
    expected = ({'kind': 'symlink', 'target': os.fsdecode(body)} if mode == '120000' else
                {'kind': 'file', 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    assert manifest[name] == expected and len(body) == size
assert sum(r[2] for r in entries.values()) == 133715342
target = blobs[entries[spec['file']][1]].decode('utf-8', errors='replace').splitlines()
assert hashlib.sha256(blobs[entries[spec['file']][1]]).hexdigest() == spec['source_sha256']

selection = {'symbol_name': spec['symbol'], 'file_path': spec['file'], 'line': 255}
requests = [('definition', 'search_symbols', {'name': spec['symbol']}), ('source', 'inspect_symbol', selection),
            ('caller_syntax', 'cross_references', selection), ('dependencies', 'dependencies', {'path': spec['file']}),
            ('tests', 'suggest_tests', {'files': [spec['file']]}),
            ('scoped_search', 'semantic_search', {'query': spec['symbol'], 'file_filter': spec['file'], 'top_k': 5})]
requests += [(q['id'], 'semantic_search', {'query': q['query'], 'top_k': 24}) for q in spec['queries']]
keys = {'inspect_symbol': ('status', 'definition', 'source', 'references', 'reference_candidates', 'tests', 'ambiguous'),
        'cross_references': ('definitions', 'references', 'reference_candidates', 'total_references', 'total_reference_candidates'),
        'dependencies': ('path', 'imports', 'imported_by', 'absence_proven'),
        'suggest_tests': ('candidates', 'absence_proven', 'evidence'), 'semantic_search': ('results',)}
phases, pids, native, raw_count = {}, set(), None, 0
for name in ('baseline-self-consistency-cold', 'baseline-self-consistency-restart', 'baseline-0-cold'):
    phase = json.loads((EVIDENCE / name / 'phase.json').read_bytes())
    assert phase['status'] == 'complete' and len(phase['operations']) == 10 and phase['pid'] not in pids
    pids.add(phase['pid'])
    journal = EVIDENCE / name / 'journal'
    completed, canonical, runtime, close = [], {}, {}, False
    for event in map(json.loads, (journal / 'events.jsonl').read_text().splitlines()):
        req, value = event['request'], load(journal, event['response'])
        if req['event'] == 'operation':
            raw_count += 1
            label, operation, args = requests[len(completed)]
            assert req == {'event': 'operation', 'label': label, 'operation': operation, 'arguments': args}
            assert not value['isError']
            data = value['structuredContent']['data']
            if operation == 'semantic_search' and data.get('ranking', {}).get('index', {}).get('status') == 'warming':
                continue
            if label == 'source':
                s = data['source']
                assert data['status'] == 'found' and data['definition']['file_path'] == spec['file'] and data['definition']['start_line'] == 255
                assert s['text'] == '\n'.join(target[s['start_line'] - 1:s['end_line']]) and spec['anchor'] in s['text']
                runtime['reference_coverage_at_source'] = value['structuredContent']['metadata']['coverage']['reference_coverage']
                runtime['hydration_phase_at_source'] = value['structuredContent']['metadata']['coverage']['phase']
            c = data if operation == 'search_symbols' else {k: data[k] for k in keys[operation] if k in data}
            row = phase['operations'][len(completed)]
            assert row['response_ref'] == event['response'] and row['canonical_sha256'] == digest(c)
            canonical[label] = c
            completed.append(label)
        elif req['event'] in {'origin_start', 'origin_end'}:
            assert value['attocode_intel'] == '__init__.py'
            assert all(not Path(p).is_absolute() and '..' not in Path(p).parts and p in freeze['engines']['baseline'] for p in value.values())
            runtime[req['event']] = value
        elif req['event'] in {'source_before', 'source_after'}:
            assert value == {'sha256': digest(manifest), 'entries': len(manifest)}
            runtime[req['event']] = value
        elif req['event'] == 'grammar_navigation':
            assert value == phase['grammar_navigation'] and value['go_direct'] and value['loaded']
            native = native or value
            assert value == native
            runtime['native_identity_equal'] = True
        elif req['event'] == 'gateway_close':
            assert value['status'] == 'complete'
            close = True
    assert len(completed) == 10 and close and all(k in runtime for k in ('origin_start', 'origin_end', 'source_before', 'source_after'))
    assert phase['evidence_sha256'] == digest({label: digest(value) for label, value in canonical.items()})
    phases[name] = {'canonical': canonical, 'sha256': phase['evidence_sha256'], 'runtime': runtime}

old, restart, new = [phases[n] for n in ('baseline-self-consistency-cold', 'baseline-self-consistency-restart', 'baseline-0-cold')]
assert old['canonical'] == restart['canonical'] and old['sha256'] != new['sha256']
changed = [label for label in old['canonical'] if old['canonical'][label] != new['canonical'][label]]
assert changed == ['source']
changed_fields = [k for k in old['canonical']['source'] if old['canonical']['source'][k] != new['canonical']['source'][k]]
assert changed_fields == ['reference_candidates']
decision = json.loads((EVIDENCE / 'decision.json').read_bytes())
assert decision['status'] == 'incomplete' and decision['decision'] is None and decision['trials'] == []
assert not any(p.name.startswith('candidate-') for p in EVIDENCE.iterdir())
assert json.loads((EVIDENCE / 'baseline-0.json').read_bytes())['workspace_removed']
verdict = {'outcome': 'incomplete_evidence_verified', 'head': HEAD, 'run': 39893315367, 'decision': None,
           'fixture_entries': len(entries), 'logical_bytes': 133715342, 'raw_responses': raw_count,
           'completed_navigation_captures': 30, 'completed_baseline_self_pair': True,
           'candidate_benchmark_phases': 0, 'changed_operation': changed, 'changed_canonical_fields': changed_fields,
           'reference_coverage_at_source': {k: v['runtime']['reference_coverage_at_source'] for k, v in phases.items()},
           'all_observed_native_identities_equal': True, 'source_native_cause': 'not established; differences coincide with incomplete reference hydration',
           'operator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ATTEMPT / 'semantic-admission.json').write_text(json.dumps(verdict, indent=2) + '\n')
print(json.dumps(verdict))
