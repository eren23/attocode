# Maintenance cost observations, 2026-10-23

The raw/ files are unchanged GitHub Actions artifact ZIP bytes. Failed and passing
attempts are retained separately. decision.json records exact runs, source heads,
checks, limits and measurement scope. operators/ preserves the actual diagnostic
versions, including failed setups. selected-source/ is the final diagnostic's
Python/config source selection. It contains no materialized third-party fixture.

The metadata-counter comparison runs no product operations. Its speed result is
specific to the pinned source-only tree and runner. It is not a full-matrix speed
forecast. The profile has global CPython3.12 attribution and observer/cache limits.
The directory-symlink accounting defect is demonstrated by its separate real
filesystem RED/GREEN control; this benchmark tree has no directory symlinks.
