# Native static workflow evidence

Run `python replay.py` after extraction. Only Python standard-library code in this archive executes; source fixtures are read as data. No network, project code, retrieval, model, parser, or language server is invoked.

This replays the original 13passed/2limited/3failed and corrected 16passed/2limited outcomes. The latter has12positive +4negative cases, with10positive explicit imported calls and2Ruby class/source/literal-require links. Rust macro calls and Ruby dynamic predicates remain limited.

The original labels were frozen before either observation; only their temporary fixture-root field is normalized here. `summary.json` retains original frozen-byte and normalized-byte hashes separately. `source-manifest.json` retains its original exact bytes. All31 fixture files are included byte-for-byte; their licenses and pinned repository/revision attribution are included separately. Rails uses the native activesupport package directory as its fixture root.

Replay checks all payload hashes and native source coordinates, then recomputes decisive definition/source/call/dependency/test/negative checks from stored responses and compares statuses. The captured service AST import-line flags were not serialized as AST objects and are identified as observations, while native import coordinates and gateway dependency edges are independently checked. This is arithmetic/source replay, not a fresh product execution or statistical reliability estimate.

Original failed observations remain in original.json. Corrected observations remain in corrected.json. The source fingerprints identify the working-tree product sources used at observation time, rather than claiming a released or current installed version. No unproven Rust readiness conclusion follows from static ripgrep controls.
