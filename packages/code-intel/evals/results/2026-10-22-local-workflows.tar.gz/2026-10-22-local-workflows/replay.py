"""Replay frozen source-bound judgments using only Python's standard library."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(name):
    return json.loads((ROOT / name).read_text())

def fixture_path(pack, path):
    return path.removeprefix('activesupport/') if pack == 'rails' else path

def replay():
    manifest = read('archive-manifest.json')
    actual = {p.relative_to(ROOT).as_posix(): digest(p.read_bytes())
              for p in ROOT.rglob('*') if p.is_file() and p.name != 'archive-manifest.json'}
    assert actual == manifest['files'], 'Archive payload missing, changed, or extended'
    labels = read('labels.json')
    summary = read('summary.json')
    assert digest((ROOT / 'source-manifest.json').read_bytes()) == summary['frozen_source_manifest_sha256']
    assert digest((ROOT / 'labels.json').read_bytes()) == summary['public_labels_sha256']
    semantic = {k: v for k, v in labels.items() if k != 'fixtures_root'}
    assert digest(json.dumps(semantic, sort_keys=True).encode()) == summary['semantic_labels_sha256']
    source = {}
    for item in read('source-manifest.json'):
        data = (ROOT / 'sources' / item['pack'] / item['fixture_path']).read_bytes()
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
        source[item['pack'], item['file']] = data.decode().splitlines()
    for case in labels['cases']:
        for anchor in [case['definition'], *sum([case[k] for k in (
                'expected_calls', 'expected_imports', 'test_source_facts', 'forbidden_calls')], [])]:
            lines = source[case['pack'], anchor['file']]
            assert lines[anchor['line'] - 1] == anchor['quote']
            item = next(r for r in read('source-manifest.json')
                        if r['pack'] == case['pack'] and r['file'] == anchor['file'])
            assert item['sha256'] == anchor['source_sha256']
    results = {}
    for run in ('original', 'corrected'):
        observations = read(run + '.json')
        assert observations['complete'] is True
        assert [c['id'] for c in observations['cases']] == [c['id'] for c in labels['cases']]
        statuses = []
        for case, row in zip(labels['cases'], observations['cases']):
            pack = case['pack']
            definition = case['definition']
            target = fixture_path(pack, definition['file'])
            data = row['responses']['inspect_symbol'][0]['data']
            selected = data.get('definition', {})
            checks = []
            def check(name, okay, **facts):
                checks.append({'name': name, 'passed': bool(okay), **facts})
            check('exact_definition', data.get('status') == 'found' and
                  (selected.get('file_path'), selected.get('start_line')) == (target, definition['line']))
            check('exact_source_head', data.get('source', {}).get('text', '').splitlines()[:1] == [definition['quote']])
            calls = {(r['file_path'], r['line']) for page in row['responses']['cross_references']
                     for r in page['data']['references'] if r['ref_kind'] == 'call'}
            dependencies = row['responses']['dependencies'][0]['data']
            for anchor in case['expected_calls']:
                expected = (fixture_path(pack, anchor['file']), anchor['line'])
                check('exact_call', expected in calls, expected=list(expected))
                if '/test' in anchor['file'] or '_test.' in anchor['file'] or '.test.' in anchor['file']:
                    check('linked_test_candidate', any(t['file_path'] == expected[0] and
                          t.get('evidence', {}).get('selected_symbol_reference') for t in data.get('tests', [])),
                          expected=expected[0])
            for anchor in case['expected_imports']:
                path = fixture_path(pack, anchor['file'])
                check('import_dependency_edge', path in dependencies.get('imported_by', []), expected=path)
                # Native source coordinates are checked above. The service AST-line
                # flag was captured during validation; AST objects were not serialized.
                observed = next(c for c in row['checks'] if c['name'] == 'exact_import_line'
                                and c['expected'] == [path, anchor['line']])
                assert observed['passed'] is True
                checks.append(observed)
            for anchor in case['forbidden_calls']:
                wrong = (fixture_path(pack, anchor['file']), anchor['line'])
                check('unrelated_not_selected_call', wrong not in calls, forbidden=list(wrong))
            assert checks == row['checks'], case['id']
            status = ('failed' if any(not c['passed'] for c in checks)
                      else 'limited' if case['limited'] else 'passed')
            assert status == row['status'], case['id']
            assert row['limited_reason'] == case['limited']
            statuses.append(status)
        counts = dict(Counter(statuses))
        assert counts == summary['runs'][run]['counts']
        metrics = summary['runs'][run]['supervision']
        assert metrics['cleanup_verified'] and metrics['owned_scratch_removed'] and metrics['source_unchanged']
        assert metrics['seconds'] < 180 and metrics['peak_rss_bytes'] < 2 * 1024**3
        assert metrics['peak_disk_bytes'] < 2 * 1024**3
        results[run] = counts
    assert Counter(c['kind'] for c in labels['cases']) == {'positive': 12, 'negative': 4, 'limited_control': 2}
    assert sum(bool(c['expected_calls']) for c in labels['cases'] if c['kind'] == 'positive') == 10
    return {'runs': results, 'source_files': len(source), 'case_count': len(labels['cases']),
            'limited_controls': [c['id'] for c in labels['cases'] if c['limited']]}

if __name__ == '__main__':
    print(json.dumps(replay(), indent=2, sort_keys=True))
