"""Independent stdlib-only retained-data admission; no product/operator imports."""
import ast
import hashlib
import json
import os
import posixpath
import subprocess
import sys
import zlib
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
ATTEMPT = Path(sys.argv[1])
PROOF = json.loads((ATTEMPT / 'admission.json').read_bytes())
assert PROOF['outcome'] == 'passed'
HEAD = PROOF['run']['head_sha']
assert PROOF['run']['status'] == 'completed' and PROOF['run']['conclusion'] == 'success' and PROOF['run']['run_attempt'] == 1
assert PROOF['artifact']['workflow_run']['head_sha'] == HEAD and PROOF['artifact']['workflow_run']['id'] == PROOF['run']['id']
archive_bytes = (ATTEMPT / 'artifact.zip').read_bytes()
assert hashlib.sha256(archive_bytes).hexdigest() == PROOF['archive_sha256']
assert PROOF['artifact']['digest'] == 'sha256:' + PROOF['archive_sha256']
with zipfile.ZipFile(ATTEMPT / 'artifact.zip') as archive:
    members = archive.infolist()
    assert len(members) == len({m.filename for m in members}) and sum(m.file_size for m in members) < 64 * 2**20
    report_members = []
    for member in members:
        name = PurePosixPath(member.filename)
        assert not name.is_absolute() and '..' not in name.parts
        if member.is_dir():
            continue
        path = ATTEMPT / name
        assert path.is_file() and not path.is_symlink() and path.read_bytes() == archive.read(member)
        if name.name == 'report.json':
            report_members.append(member)
    assert len(report_members) == 1 and json.loads(archive.read(report_members[0])) == PROOF['report']
REPORT = PROOF['report']
assert REPORT['identity']['commit'] == HEAD and REPORT['identity']['github_run_id'] == str(PROOF['run']['id'])
assert REPORT['status'] == 'complete' and REPORT['decision'] is None
assert REPORT['limits'] == {'seconds': 600, 'disk_bytes': 2**31, 'rss_bytes': 2**31, 'evidence_bytes': 64 * 2**20}
assert REPORT['seconds'] < 600
EVIDENCE = ATTEMPT / PurePosixPath(report_members[0].filename).parent
verified_members = {m.filename for m in members if not m.is_dir()}
assert (EVIDENCE / 'workflows.json').relative_to(ATTEMPT).as_posix() in verified_members
assert (EVIDENCE / 'runtime-platform.json').relative_to(ATTEMPT).as_posix() in verified_members
runtime_platform = json.loads((EVIDENCE / 'runtime-platform.json').read_bytes())
assert runtime_platform['target']['runner'] == 'ubuntu-latest'
assert runtime_platform['actual']['sys_platform'] == runtime_platform['target']['sys_platform'] == 'linux'
assert runtime_platform['actual']['machine'] == runtime_platform['target']['machine'] == 'x86_64'
assert runtime_platform['actual']['platform'] == REPORT['identity']['platform']
result = json.loads((EVIDENCE / 'workflows.json').read_bytes())
static_bytes = (ROOT / 'broad-static-manifest.json').read_bytes()
assert hashlib.sha256(static_bytes).hexdigest() == '5e06a426be28113dc24066017b387db097cba0210b7ff4293c7581b5baedd65a'  # Reviewed static YAML normalization.
static = json.loads(static_bytes)
pack_bytes = subprocess.check_output(['git', 'show', HEAD + ':eval/quality/workflows.yaml'])
assert static['sha256'] == hashlib.sha256(pack_bytes).hexdigest() == result['pack_sha256']
specs = [{**s, 'queries': []} for s in static['static_yaml']['repositories'] if s['id']=='ocaml']
assert len(specs) == 1 and sum(len(s['queries']) for s in specs) == 0
assert result['passed'] and result['complete'] and result['cleanup_verified']
assert result['selected_packs'] == [s['id'] for s in specs] == result['manifest_packs']
assert [r['id'] for r in result['repositories']] == result['selected_packs']
assert result['model_runs'] == 0
files = REPORT['identity']['files']
source = subprocess.check_output(['git', 'show', HEAD + ':packages/code-intel/src/attocode_intel/_internal/integrations/context/codebase_context.py'])
skip = {}
for n in ast.parse(source).body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in {'SKIP_EXTENSIONS', 'SKIP_FILENAMES'}:
        skip[n.targets[0].id] = ast.literal_eval(n.value)
HISTORY = Path('/Users/eren/Documents/AI/attocode-evals/matrix')
CLONES = Path('/Users/eren/Documents/ai/benchmark-repos')
REPO = next(p for p in ROOT.parents if (p / '.git').exists())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def entries(folder):
    assert (folder / 'events.jsonl').relative_to(ATTEMPT).as_posix() in verified_members
    events = []
    for line in (folder / 'events.jsonl').read_bytes().splitlines():
        event = json.loads(line)
        ref = event['response']
        assert ref['path'] == f'blobs/{ref["sha256"]}.json' and type(ref['bytes']) is int
        assert (folder / ref['path']).relative_to(ATTEMPT).as_posix() in verified_members
        raw = (folder / ref['path']).read_bytes()
        assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256']
        events.append((event['request'], ref, json.loads(raw)))
    return events


def origins(value):
    assert value['origins']['attocode_intel'] == '__init__.py' and type(value['pid']) is int
    for name, relative in value['origins'].items():
        p = PurePosixPath(relative)
        assert name.startswith('attocode_intel') and not p.is_absolute() and '..' not in p.parts
        assert 'packages/code-intel/src/attocode_intel/' + relative in files


controller = entries(EVIDENCE / 'broad/controller')
assert [r['event'] for r, _, _ in controller] == ['origin_start', 'origin_end']
for _, _, value in controller:
    origins(value)
pids = {controller[0][2]['pid']}
assert controller[1][2]['pid'] in pids
outcomes, fixture_sizes, raw_count, observed = Counter(), {}, 0, []
policies = {'body_index': ('replace', 'universal'), 'hydrated_metadata': ('strict', 'raw'), 'exact_scoped_source': ('replace', 'raw')}
for spec, row in zip(specs, result['repositories'], strict=True):
    assert row['revision'] == spec['commit'] and row['status'] == 'passed' and row['passed'] and row['cleanup_verified']
    assert row['phase'] == 'finished' and not row.get('error') and not row.get('worker_error')
    folder = EVIDENCE / 'broad' / spec['id']
    fixture = entries(folder / 'fixture')
    assert len(fixture) == 1
    request, ref, manifest = fixture[0]
    assert request == {'event': 'fixture_pinned', 'repo': spec['repo'], 'commit': spec['commit'], 'tree': row['tree']}
    assert ref == row['fixture_ref']
    historical = HISTORY / 'trees' / (spec['repo'].replace('/', '__') + '@' + spec['commit'] + '.json')
    clone = REPO if spec['id'] == 'frontend' else CLONES / spec['id']
    from_history = historical.is_file()
    if from_history:
        tree = json.loads(historical.read_bytes())
        listed = tree['entries']
        assert tree['tree'] == row['tree']
    else:
        data = subprocess.check_output(['git', '-C', str(clone), 'ls-tree', '-r', '-l', '-z', spec['commit']], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0'})
        listed = []
        for item in data.split(b'\0'):
            if item:
                meta, name = item.split(b'\t', 1)
                mode, kind, oid, size = meta.decode().split()
                listed.append([os.fsdecode(name), mode, oid, int(size) if kind == 'blob' else 0])
        assert subprocess.check_output(['git', '-C', str(clone), 'rev-parse', spec['commit'] + '^{tree}'], text=True).strip() == row['tree']
    selected = {}
    for name, mode, oid, size in listed:
        if spec.get('subdir'):
            prefix = spec['subdir'] + '/'
            if not name.startswith(prefix):
                continue
            name = name.removeprefix(prefix)
        if spec.get('include') and not any(name == p or name.startswith(p + '/') for p in spec['include']):
            continue
        if mode == '120000' or (mode in {'100644', '100755'} and 0 <= size <= 1000000
                and Path(name).suffix.lower() not in skip['SKIP_EXTENSIONS'] and Path(name).name not in skip['SKIP_FILENAMES']):
            assert name not in selected
            selected[name] = mode, oid, size
    assert selected.keys() == manifest.keys(), spec['id']
    bodies = {}
    if not from_history:
        oids = sorted({v[1] for v in selected.values()})
        assert sum(v[2] for v in selected.values()) <= 512 * 2**20
        packet = subprocess.check_output(['git', '-C', str(clone), 'cat-file', '--batch'],
            input=''.join(oid + '\n' for oid in oids).encode(),
            env={**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0'})
        offset = 0
        for expected_oid in oids:
            end = packet.index(b'\n', offset)
            fields = packet[offset:end].decode().split()
            assert len(fields) == 3 and fields[:2] == [expected_oid, 'blob'], 'required existing Git blob unavailable'
            size = int(fields[2]);body = packet[end + 1:end + 1 + size]
            assert len(body) == size and hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + body).hexdigest() == expected_oid
            assert packet[end + 1 + size:end + 2 + size] == b'\n'
            bodies[expected_oid] = body
            offset = end + 2 + size
        assert offset == len(packet)
        del packet
    for name, (mode, oid, size) in selected.items():
        if oid not in bodies:
            if from_history:
                body = zlib.decompress((HISTORY / 'blobs' / oid[:2] / oid[2:]).read_bytes())
            else:
                raise AssertionError('required Git blob was not admitted in batch')
            assert len(body) == size and hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == oid
            bodies[oid] = body
        body = bodies[oid]
        expected = {'kind': 'symlink', 'target': os.fsdecode(body)} if mode == '120000' else {'kind': 'file', 'bytes': size, 'sha256': sha(body)}
        assert manifest[name] == expected
    fixture_sizes[spec['id']] = {'entries': len(manifest), 'bytes': sum(v[2] for v in selected.values()), 'sha256': digest(manifest)}

    def body_for(name):
        for _ in range(20):
            parts = PurePosixPath(name).parts
            for n in range(1, len(parts) + 1):
                prefix = '/'.join(parts[:n])
                if prefix in manifest and manifest[prefix]['kind'] == 'symlink':
                    name = posixpath.normpath(posixpath.join(posixpath.dirname(prefix), manifest[prefix]['target'], *parts[n:]))
                    assert not name.startswith('../') and not name.startswith('/')
                    break
            else:
                return bodies[selected[name][1]]
        raise AssertionError('source symlink cycle')

    runtime, captured, lineage, pending, closed = {}, [], {}, None, set()
    for request, ref, value in entries(folder / 'journal'):
        kind = request['event']
        if kind in {'origin_start', 'origin_end', 'source_before', 'source_after'}:
            assert kind not in runtime
            runtime[kind] = value
        elif kind == 'source_lineage':
            key = tuple(request['identity'])
            if value['producer'] != 'metadata':
                assert sha(body_for(key[0])) == value['source_sha256']
            lineage[key] = value
        elif kind == 'mcp_response':
            assert pending is None and request['gateway'] not in closed
            assert request['sequence'] == sum(c['gateway'] == request['gateway'] for c in captured)
            if request['gateway'] == 1:
                assert 0 in closed
            page = json.loads(value['content'][0]['text'])
            pending = {'gateway': request['gateway'], 'sequence': request['sequence'], 'response_ref': ref,
                       'request': request, 'raw': value, 'page': page, 'lineage': lineage}
            lineage = {}
            raw_count += 1
        elif kind == 'source_validation':
            assert pending is not None
            assert all(request[k] == pending[k] for k in ('gateway', 'sequence', 'response_ref'))
            page, tool, expected = pending['page'], pending['request']['tool'], []
            if tool == 'semantic_search' and 'results' in page.get('data', {}):
                actual_policies = []
                for hit in page['data']['results']:
                    key = tuple(hit.get(k) for k in ('file_path', 'name', 'chunk_type', 'line', 'end_line'))
                    policy = pending['lineage'][key]
                    actual_policies.append(policy)
                    first, last = hit.get('snippet_start_line'), hit.get('snippet_end_line')
                    if first is None and last is None:
                        assert policy['producer'] == 'metadata' or not hit.get('snippet')
                        expected.append({'kind': 'metadata_only', 'spans': []})
                        continue
                    errors, newlines = policies[policy['producer']]
                    assert (policy['errors'], policy['newlines']) == (errors, newlines)
                    text = body_for(hit['file_path']).decode('utf-8', errors=errors)
                    if newlines == 'universal':
                        text = text.replace('\r\n', '\n').replace('\r', '\n')
                    lines, offsets = text.splitlines(keepends=True), [0]
                    for line in lines:
                        offsets.append(offsets[-1] + len(line))
                    assert all(type(n) is int for n in (hit['line'], hit['end_line'], first, last))
                    assert 1 <= hit['line'] <= first <= last <= hit['end_line'] <= len(lines)
                    window, spans = text[offsets[first - 1]:offsets[last]], []
                    start = window.find(hit['snippet'])
                    while start >= 0:
                        begin, end = offsets[first - 1] + start, offsets[first - 1] + start + len(hit['snippet'])
                        if begin < offsets[first] and end > offsets[last - 1]:
                            spans.append([begin, end])
                        start = window.find(hit['snippet'], start + 1)
                    assert spans
                    expected.append({'kind': 'source', 'spans': spans, 'policy': policy})
                assert request['policies'] == actual_policies
            elif tool == 'inspect_symbol':
                data = page['data']
                for excerpt in [data.get('source', {}), *data.get('source_excerpts', [])]:
                    if excerpt.get('text'):
                        name = excerpt.get('file_path', data['definition']['file_path'])
                        lines = body_for(name).decode('utf-8', errors='replace').splitlines()
                        first, last = excerpt['start_line'], excerpt['end_line']
                        assert 1 <= first <= last <= len(lines) and excerpt['text'] == '\n'.join(lines[first - 1:last])
                        expected.append({'kind': 'source', 'file_path': name, 'start_line': first, 'end_line': last,
                                         'errors': 'replace', 'newlines': 'universal', 'line_join': 'LF'})
            assert value == expected
            captured.append(pending)
            pending = None
        elif kind == 'gateway_close':
            assert pending is None and value == {'status': 'complete'} and request['gateway'] not in closed
            closed.add(request['gateway'])
        else:
            assert kind == 'preview_input_identity'
    assert set(runtime) == {'origin_start', 'origin_end', 'source_before', 'source_after'} and closed == {0, 1} and pending is None
    assert runtime['source_before'] == runtime['source_after'] == {'sha256': digest(manifest)}
    for kind in ('origin_start', 'origin_end'):
        origins(runtime[kind])
    pid = runtime['origin_start']['pid']
    assert pid == runtime['origin_end']['pid'] and pid not in pids
    pids.add(pid)
    # Every request is consumed once, in the workflow's actual operation order.
    checks, questions = row['checks'], row['retrieval']
    assert [r['name'] for r in checks] == ['definition', 'source', 'scoped_search', 'caller_syntax', 'dependencies', 'impact', 'tests', 'restart']
    assert [q['id'] for q in questions] == [q['id'] for q in spec['queries']] == row['expected_questions']
    ordered = [*checks[:7], *questions, checks[-1]]
    at = 0
    selected_line = (body_for(spec['file']).decode('utf-8').replace('\r\n', '\n').replace('\r', '\n').split(spec['anchor'], 1)[0].count('\n') + 1)
    selection = {'symbol_name': spec['symbol'], 'file_path': spec['file'], 'line': selected_line}
    for item in ordered:
        label = item.get('name')
        check_requests = {
            'definition': ('search_symbols', {'name': spec['symbol']}),
            'source': ('inspect_symbol', selection), 'restart': ('inspect_symbol', selection),
            'scoped_search': ('semantic_search', {'query': spec.get('query', spec['symbol']), 'file_filter': spec['file'], 'top_k': 5}),
            'caller_syntax': ('cross_references', {'symbol_name': spec['symbol']}),
            'dependencies': ('dependencies', {'path': spec['file']}),
            'impact': ('impact_analysis', {'changed_files': [spec['file']]}),
            'tests': ('suggest_tests', {'files': [spec['file']]})}
        tool, arguments = check_requests[label] if label else ('semantic_search', {'query': item['query'], 'top_k': 24})
        expected_arguments = {'max_tokens': 4000 if label else 8000, **arguments}
        expected_gateway = 1 if label == 'restart' else 0
        refs = item['response_refs']
        assert refs
        for ref in refs:
            assert ref == {k: captured[at][k] for k in ('gateway', 'sequence', 'response_ref')}
            req = captured[at]['request']
            assert req['tool'] == tool and req['arguments'] == expected_arguments and req['gateway'] == expected_gateway
            data = captured[at]['page'].get('data', {})
            if label == 'caller_syntax' and data.get('next_cursor'):
                expected_arguments = {**expected_arguments, 'cursor': data['next_cursor']}
            at += 1
        if label == 'definition':
            choices = [d for d in captured[at - 1]['page']['data'] if d['file_path'] == spec['file'] and (
                d['name'] in {spec['symbol'], spec['symbol'].split('.')[-1]}
                or ('.' not in spec['symbol'] and d['name'].split('.')[-1] == spec['symbol']))]
            if len(choices) > 1:
                choices = [d for d in choices if d['start_line'] <= selected_line <= d['end_line']]
            if len(choices) == 1:
                selection['line'] = choices[0]['start_line']
        if 'name' in item:
            assert item['outcome'] in {'passed', 'limited', 'unsupported'}
            assert item['passed'] == (item['outcome'] == 'passed')
            data = captured[at - 1]['page'].get('data', {})
            if label == 'definition':
                predicate = any(d['file_path'] == spec['file'] and (d['name'] in {spec['symbol'], spec['symbol'].split('.')[-1]}
                    or ('.' not in spec['symbol'] and d['name'].split('.')[-1] == spec['symbol'])) for d in data)
            elif label in {'source', 'restart'}:
                predicate = data.get('status') == 'found' and data['definition']['file_path'] == spec['file'] and (label == 'restart' or bool(data.get('source', {}).get('text')))
            elif label == 'scoped_search':
                predicate = bool(data.get('results')) and all(h['file_path'] == spec['file'] for h in data['results'])
            elif label == 'caller_syntax':
                predicate = any(r['file_path'] == spec['caller'] for r in data.get('references', [])) if spec['caller'] else not data.get('absence_proven', False)
            elif label == 'dependencies':
                predicate = spec['importer'] in data.get('imported_by', []) if spec['importer'] else not data.get('absence_proven', False)
            elif label == 'impact':
                predicate = not data.get('absence_proven', False) and (not spec['importer'] or spec['importer'] in data.get('impacted_files', [])
                    or any(spec['importer'] in layer['files'] for layer in data.get('layers', [])))
            else:
                predicate = not data.get('absence_proven', False) and (not spec['test'] or any(r['file_path'] == spec['test'] for r in data.get('candidates', [])))
            contract = not captured[at - 1]['raw'].get('isError', False) and bool(predicate)
            assert item['contract_passed'] == contract
            if contract:
                limited = label in {'caller_syntax', 'dependencies', 'impact', 'tests'} and not {
                    'caller_syntax': spec['caller'], 'dependencies': spec['importer'], 'impact': spec['importer'], 'tests': spec['test']}[label]
                assert item['outcome'] == ('limited' if limited else 'passed')
            else:
                assert item['outcome'] == 'unsupported'
            assert item['response'] == {'ref': refs[-1]['response_ref']}
            outcomes[item['outcome']] += 1
        else:
            q = next(q for q in spec['queries'] if q['id'] == item['id'])
            for label in q['evidence']:
                text = body_for(label['file']).decode('utf-8').replace('\r\n', '\n').replace('\r', '\n')
                assert sha(text.encode()) == label['source_sha256'] and label['quote'] in text
            data = captured[at - 1]['page']['data']
            ranked = list(dict.fromkeys(h['file_path'] for h in data.get('results', [])))
            labels = sorted({label['file'] for label in q['evidence']})
            ranks = [i + 1 for i, name in enumerate(ranked) if name in labels]
            assert item['query'] == q['query'] and item['ranked_files'] == ranked and item['labeled_files'] == labels
            assert item['first_labeled_rank'] == (min(ranks) if ranks else None)
            assert item['hit_at_5'] == any(r <= 5 for r in ranks) and item['hit_at_24'] == any(r <= 24 for r in ranks)
            observed.append(item)
    assert at == len(captured) == row['admission']['responses']
    assert row['admission']['source_sha256'] == digest(manifest) and row['admission']['worker_pid'] == pid
    print(json.dumps({'pack': spec['id'], 'fixture_entries': len(manifest), 'responses': len(captured)}), flush=True)
assert sum(outcomes.values()) == 8 and len(observed) == 0 and len(pids) == 2
assert result['outcomes'] == {name: outcomes.get(name, 0) for name in ('passed', 'failed', 'limited', 'unsupported', 'incomplete')}
assert result['retrieval']['observed_questions'] == 0 and not result['retrieval']['missing_questions']
assert result['retrieval']['labeled_hit_at_5'] == sum(q['hit_at_5'] for q in observed)
assert result['retrieval']['labeled_hit_at_24'] == sum(q['hit_at_24'] for q in observed)
import importlib.util
private_spec=importlib.util.spec_from_file_location('private_native_data',ROOT/'verify_native_data.py');private=importlib.util.module_from_spec(private_spec);private_spec.loader.exec_module(private)
smoke=PROOF['smoke'];worker=json.loads((EVIDENCE/'worker.json').read_bytes());spec=specs[0]
trace=EVIDENCE/'broad/ocaml/native-ocaml.jsonl';assert trace.relative_to(ATTEMPT).as_posix() in verified_members
native=private.admit_native(trace.read_bytes(),worker['native_capture'],spec,smoke['workspace'],files,pid)
assert native['selected_source_parses']>0 and native['parse_calls']>0
assert result['repositories'][0]['admission']['native_capture']['selected_source_parses']==native['selected_source_parses']
assert all(c['page']['metadata']['workspace']==smoke['workspace'] for c in captured)
assert smoke['worker_command'][1:4]==['-m','eval.quality.corpus','--worker'] and smoke['worker_command'][4]==smoke['workspace']
proof = {'outcome': 'passed', 'operator_sha256': sha(Path(__file__).read_bytes()), 'head': HEAD,
         'source_tree': subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], text=True).strip(),
         'run': PROOF['run']['id'], 'archive_sha256': PROOF['archive_sha256'], 'raw_responses': raw_count,
         'packs': 1, 'outcomes': result['outcomes'], 'retrieval': result['retrieval'], 'fixtures': fixture_sizes,
         'worker_origins': 1, 'controller_origins': True, 'cleanup_verified': True, 'runtime_platform': runtime_platform,
         'source_fixture_reads': 'Existing pinned Git/compressed blobs in memory only; no local fixture materialization or product/operator execution',
         'budget_verification': 'Source-bound online token admission; independent host replay does not execute tokenizer or tested operators',
         'unsupported_policy_verification': 'Eligibility (actual grammar availability/workspace ignore policy) is recomputed by source-bound online admit_worker; host independently replays raw contract predicates and does not turn false contracts into passing assertions',
         'static_manifest_sha256': hashlib.sha256(static_bytes).hexdigest(), 'native_capture': native, 'issued_retrieval_questions': 0, 'scope':'One pinned OCaml routine-worker capture smoke; no breadth/relevance/performance/nativecause verdict'}
(ATTEMPT / 'semantic-admission.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items() if k != 'fixtures'}))
