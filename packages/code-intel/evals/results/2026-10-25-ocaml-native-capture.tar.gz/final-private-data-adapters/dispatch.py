"""Dispatch a named authorized attempt once; refuse duplicate request files."""
import argparse,json,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('experiment');p.add_argument('label');a=p.parse_args();root=Path(__file__).parent
assert a.experiment=='ocamlcapture' and a.label in {'red-1','green-1','route-red-1','route-green-1','smoke-1'}
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert branch=='test/ocaml-failure-capture' and not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/eren23/attocode/'+path],timeout=45))
assert api('branches/'+branch)['commit']['sha']==head
if a.label=='smoke-1':
 import hashlib
 qualified=json.loads((root/'smoke-source-qualification.json').read_bytes());design_path=Path('eval/quality/experiments/ocamlcapture.json');design=json.loads(design_path.read_bytes())
 assert qualified['outcome']=='passed' and qualified['controls']==373 and qualified['schema_version']==2 and design['stage']=='smoke'
 assert design['capture_source_sha256']==qualified['capture_source_sha256'] and all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in design['capture_source_sha256'].items())
 assert design['smoke']['routine_worker_processes']==1 and design['smoke']['fixture']['queries']==[] and design['smoke']['worker_seconds']==180
 with (root/'smoke-authorization.json').open('x') as f:json.dump({'head':head,'qualified':qualified,'design_sha256':hashlib.sha256(design_path.read_bytes()).hexdigest(),'one_worker':True,'no_replacement_rerun_retune':True,'limits':design['limits'],'created_unix':time.time()},f,indent=2)
request=root/(a.label+'-request.json');assert not request.exists();old={r['id'] for r in api('actions/workflows/intelligence-experiments.yml/runs?per_page=100')['workflow_runs']}
request.write_text(json.dumps({'experiment':a.experiment,'head':head,'branch':branch,'previous_run_ids':sorted(old),'created_unix':time.time()},indent=2)+'\n')
subprocess.run(['gh','workflow','run','intelligence-experiments.yml','--repo','eren23/attocode','--ref',branch,'-f','experiment='+a.experiment],check=True,timeout=45)
for _ in range(12):
 rows=[r for r in api('actions/workflows/intelligence-experiments.yml/runs?per_page=100')['workflow_runs'] if r['id'] not in old and r['head_sha']==head and r['event']=='workflow_dispatch']
 if rows:
  assert len(rows)==1;r=rows[0];(root/(a.label+'-dispatch.json')).write_text(json.dumps({'run':r,'observed_unix':time.time()},indent=2)+'\n');print(json.dumps({k:r[k] for k in ('id','head_sha','status','html_url')}));break
 time.sleep(2)
else:raise RuntimeError('request sent; metadata unavailable; do not redispatch')
