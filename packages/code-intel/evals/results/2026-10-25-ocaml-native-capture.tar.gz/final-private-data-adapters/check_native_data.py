"""Private JSON fault controls; no product or tested harness imports."""
import copy,hashlib,importlib.util,json,pathlib
R=pathlib.Path(__file__).parent
s=importlib.util.spec_from_file_location('retained_native',R/'verify_native_data.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
files={n:'a'*64 for n in m.SOURCE_KEYS};spec={'id':'ocaml','repo':'x','commit':'f'*40,'language':'ocaml','file':'a.ml','source_sha256':'b'*64}
counts={n:0 for n in m.COUNTS};counts.update(parse_calls=1,native_failures=1)
summary={'status':'complete','bytes':0,**counts,'worker_error':None}
identity={'parser_generation':1,'parser_id':123,'thread_id':456}
data=[{'kind':'trace_start','schema_version':2,'workspace':'/owned/ocaml','fixture':spec,'sources':files,'runtime':{'pid':7},'limits':{'max_bytes':4194304,'event_bytes':65536,'prefix_bytes':3142656,'tail_bytes':1047552}},
 {'kind':'native','native':{**identity,'stage':'parser','origin':'generic','language':'ocaml'}},
 {'kind':'native','native':{**identity,'stage':'timeout_set','value':100000}},
 {'kind':'native','native':{**identity,'stage':'parse','language':'ocaml','limit_micros':100000,'wall_ns':10,'thread_cpu_ns':5,'bytes':4,'source_sha256':spec['source_sha256'],'thread_name':'worker','error':{'type':'ValueError','message':'native'},'outcome':'ValueError'}},
 {'kind':'native','native':{**identity,'stage':'reset'}},
 {'kind':'trace_end','status':'complete',**counts,'worker_error':None}]
def check(d,summary,valid):
 for i,row in enumerate(d,1):row.update(index=i,monotonic_ns=i)
 raw=('\n'.join(json.dumps(x) for x in d)+'\n').encode();summary['bytes']=len(raw)
 try:result=m.admit_native(raw,summary,spec,'/owned/ocaml',files,7)
 except (AssertionError,KeyError,IndexError,ValueError):assert not valid
 else:assert valid and result['selected_source_parses']==1
checks=[]
for name in ('valid','footer','source','clock','reset','counter_bool','summary_loss','generation','registration'):
 d=copy.deepcopy(data);summ=copy.deepcopy(summary)
 if name=='footer':d.pop()
 elif name=='source':d[0]['sources'][m.SOURCE_KEYS[0]]='0'*64
 elif name=='clock':d[3]['native']['thread_cpu_ns']=-1
 elif name=='reset':d.pop(4)
 elif name=='counter_bool':d[-1]['capture_errors']=False
 elif name=='summary_loss':summ['status']='incomplete'
 elif name=='generation':d[3]['native']['parser_generation']=2
 elif name=='registration':d[1]['native']['origin']='invented'
 check(d,summ,name=='valid');checks.append(name+('_accept' if name=='valid' else '_reject'))
proof={'outcome':'passed','checks':checks,'no_tested_operator_or_product_execution':True,'operator_sha256':hashlib.sha256((R/'verify_native_data.py').read_bytes()).hexdigest()}
(R/'native-data-schema2-controls.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
