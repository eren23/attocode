"""Read-only admission of one existing manual experiment attempt."""
import argparse
import hashlib
import io
import json
import subprocess
import stat
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path, PurePosixPath

p = argparse.ArgumentParser()
p.add_argument('run', type=int)
p.add_argument('head')
p.add_argument('experiment')
p.add_argument('out', type=Path)
args = p.parse_args()
args.out.mkdir(exist_ok=False)
def get(path):
    return subprocess.check_output(['gh', 'api', 'repos/eren23/attocode/' + path], timeout=120)
run = json.loads(get(f'actions/runs/{args.run}'))
assert run['status'] == 'completed'
assert run['head_sha'] == args.head and type(run['run_attempt']) is int and run['run_attempt'] == 1 and run['event']=='workflow_dispatch'
assert run['path'] == '.github/workflows/intelligence-experiments.yml'
artifacts = json.loads(get(f'actions/runs/{args.run}/artifacts'))['artifacts']
found = [a for a in artifacts if a['name'] == f'experiment-{args.experiment}-{args.run}-1']
assert len(found) == 1 and not found[0]['expired'] and found[0]['workflow_run']['head_sha'] == args.head
a = found[0]
raw = get(f'actions/artifacts/{a["id"]}/zip')
sha = hashlib.sha256(raw).hexdigest()
assert len(raw) < 64 * 2**20 and (not a.get('digest') or a['digest'] == 'sha256:' + sha)
(args.out / 'artifact.zip').write_bytes(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert sum(e.file_size for e in z.infolist()) < 64 * 2**20
    assert len(z.infolist()) == len(set(e.filename for e in z.infolist()))
    for e in z.infolist():
        path = PurePosixPath(e.filename)
        assert not path.is_absolute() and '..' not in path.parts
    for entry in z.infolist():
        assert not stat.S_ISLNK(entry.external_attr >> 16)
    z.extractall(args.out)
    for entry in z.infolist():
        if not entry.is_dir(): assert (args.out / entry.filename).read_bytes() == z.read(entry)
reports = list(args.out.rglob('report.json'))
assert len(reports) == 1
evidence = reports[0].parent
r = json.loads(reports[0].read_bytes())
if run['conclusion'] != 'success' or r['status'] != 'complete':
    proof={'outcome':'retained-incomplete','run':run,'artifact':a,'archive_sha256':sha,'report':r,
           'operator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (args.out/'admission.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({'outcome':'retained-incomplete','archive_sha256':sha}))
    raise SystemExit(0)
assert r['experiment'] == args.experiment and r['status'] == 'complete' and r['decision'] is None
assert r['cleanup_verified'] and r['owned_scratch_removed'] and r['identity']['commit'] == args.head
assert r['identity']['github_run_id'] == str(args.run)
design_raw=subprocess.check_output(['git','show',args.head+':eval/quality/experiments/' + args.experiment + '.json'])
assert hashlib.sha256(design_raw).hexdigest()==r['identity']['design_sha256']
assert r['limits']==json.loads(design_raw)['limits']
assert r['limits']=={'seconds':600,'disk_bytes':2**31,'rss_bytes':2**31,'evidence_bytes':64*2**20}
assert r['supervision']['exit_code'] == 0 and r['supervision']['status'] == 'passed'
assert not r['supervision']['log_truncated'] and r['supervision']['cleanup_verified']
assert r['seconds'] < r['limits']['seconds'] and r['supervision']['peak_rss_bytes'] < 2**31
assert r['supervision']['peak_disk_bytes'] < 2**31 and r['supervision']['peak_evidence_bytes'] < 63 * 2**20
roots = ['eval', 'packages/code-intel', 'pyproject.toml', 'uv.lock', '.github/workflows/intelligence-experiments.yml']
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', args.head, '--', *roots]).decode().splitlines()
assert set(paths) == set(r['identity']['files'])
for name, expected in r['identity']['files'].items():
    committed = subprocess.check_output(['git', 'show', args.head + ':' + name])
    assert hashlib.sha256(committed).hexdigest() == expected, name
for filename in ('controller-origin.json', 'controller-complete.json'):
    record = json.loads((evidence / filename).read_bytes())
    for name, relative in record['origins'].items():
        path = PurePosixPath(relative)
        assert name.startswith('attocode_intel') and not path.is_absolute() and '..' not in path.parts
        assert 'packages/code-intel/src/attocode_intel/' + relative in paths
complete = json.loads((evidence / 'controller-complete.json').read_bytes())
assert complete['complete'] is True
xml = []
for path in args.out.rglob('*.xml'):
    body = path.read_bytes()
    assert b'<!DOCTYPE' not in body.upper()
    tree = ET.fromstring(body)
    assert not list(tree.iter('error')) and not list(tree.iter('skipped'))
    cases = list(tree.iter('testcase'))
    xml.append({'path': str(path.relative_to(args.out)), 'cases': len(cases),
                'passed': sum(c.find('skipped') is None and c.find('failure') is None for c in cases)})
journals = []
for events in args.out.rglob('events.jsonl'):
    count = 0
    for line in events.read_bytes().splitlines():
        event = json.loads(line)
        ref = event['response']
        path = PurePosixPath(ref['path'])
        assert not path.is_absolute() and '..' not in path.parts
        blob = (events.parent / path).read_bytes()
        assert len(blob) == ref['bytes'] and hashlib.sha256(blob).hexdigest() == ref['sha256']
        count += 1
    journals.append({'path': str(events.relative_to(args.out)), 'events': count})
verdict=json.loads((evidence/'smoke-verdict.json').read_bytes())
assert verdict['status']=='complete' and verdict['decision'] is None and verdict['worker_launched'] is True and verdict['worker_exit_code']==0
assert verdict['worker_processes']==1 and verdict['issued_retrieval_questions']==0 and verdict['workflow_checks']==8 and verdict['fixture_removed'] is True and verdict['grammar_identity_unchanged'] is True
before=json.loads((evidence/'grammar-before.json').read_bytes());after=json.loads((evidence/'grammar-after.json').read_bytes());assert before==after and before['cache_files'] and set(before['distributions'])=={'tree-sitter','tree-sitter-language-pack'}
worker=json.loads((evidence/'worker.json').read_bytes());assert not worker.get('worker_error') and worker['retrieval']==[] and worker['native_capture']['status']=='complete'
assert not xml and len(journals)==3
proof={'operator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'outcome':'passed','run':run,'artifact':a,'archive_sha256':sha,'report':r,'smoke':verdict,'xml':xml,'journals':journals}
(args.out/'admission.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'outcome':'passed','run':args.run,'head':args.head,'archive_sha256':sha,'seconds':r['seconds'],'native_capture':verdict['native_capture'],'workflow_checks':8,'retrieval_questions':0}))
