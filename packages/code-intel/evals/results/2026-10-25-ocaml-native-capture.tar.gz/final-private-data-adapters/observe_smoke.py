"""Observe and collect the one existing native smoke; never launch or rerun."""
import json,pathlib,subprocess,sys
r=pathlib.Path(__file__).parent;d=json.loads((r/'smoke-1-dispatch.json').read_bytes())['run']
for label,command in [('watch',[str(r/'watch_attempt.py'),str(d['id']),d['head_sha'],'smoke-1']),('collect',[str(r/'collect_smoke.py'),str(d['id']),d['head_sha'],'ocamlcapture',str(r/'smoke-1')]),('semantic',[str(r/'verify_smoke.py'),str(r/'smoke-1')])]:
 with (r/('smoke-1-'+label+'.log')).open('w') as stream:subprocess.run([sys.executable,*command],stdout=stream,stderr=subprocess.STDOUT,check=True)
print('ONE_NATIVE_SMOKE_ADMITTED',d['id'],d['head_sha'],flush=True)
