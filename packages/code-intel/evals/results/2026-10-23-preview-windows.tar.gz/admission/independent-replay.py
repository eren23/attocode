"""Independent data-only replay; never imports product or maintained operators."""
import ast
import hashlib
import json
import math
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ATTEMPT = ROOT / 'preview-attempt-1'
PROOF = json.loads((ATTEMPT / 'admission.json').read_bytes())
EVIDENCE = ATTEMPT / 'intelligence-experiment-39888662258-1/evidence/preview'
HEAD = 'f34661699db7bcf515cb05115d5255941bbcdad8'
assert PROOF['run']['head_sha'] == HEAD


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


design = json.loads(subprocess.check_output(['git', 'show', HEAD + ':packages/code-intel/evals/designs/2026-10-23-preview-windows.json']))
skip_source = subprocess.check_output(['git', 'show', HEAD + ':packages/code-intel/src/attocode_intel/_internal/integrations/context/codebase_context.py'])
skip = {}
for node in ast.parse(skip_source).body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in {'SKIP_EXTENSIONS', 'SKIP_FILENAMES'}:
        skip[node.targets[0].id] = ast.literal_eval(node.value)
policies = {'body_index': ('replace', 'universal'), 'hydrated_metadata': ('strict', 'raw'), 'exact_scoped_source': ('replace', 'raw')}
pairs, timing, checked, fixture_sizes = {}, {'baseline': [], 'candidate': []}, 0, {}

for pack in design['packs']:
    destination = EVIDENCE / pack['id']
    observation = json.loads((destination / 'pages.json').read_bytes())
    assert observation['status'] == 'complete' and len(observation['pages']) == 360
    journal = destination / 'journal'

    def load(ref):
        assert ref['path'] == f'blobs/{ref["sha256"]}.json'
        raw = (journal / ref['path']).read_bytes()
        assert len(raw) == ref['bytes'] and digest(raw) == ref['sha256']
        return json.loads(raw)

    manifest = load(observation['fixture_ref'])
    clone = Path('/Users/eren/Documents/ai/benchmark-repos') / pack['id']
    listing = subprocess.check_output(['git', '-C', str(clone), 'ls-tree', '-r', '-l', '-z', pack['commit'], '--', *pack['include']])
    entries = {}
    for item in listing.split(b'\0'):
        if not item:
            continue
        meta, rawname = item.split(b'\t', 1)
        mode, kind, oid, size = meta.decode().split()
        name = os.fsdecode(rawname)
        if mode == '120000' or (mode in {'100644', '100755'} and 0 <= int(size) <= 1000000
                and Path(name).suffix.lower() not in skip['SKIP_EXTENSIONS'] and Path(name).name not in skip['SKIP_FILENAMES']):
            entries[name] = (mode, oid, int(size))
    assert set(entries) == set(manifest)
    oids = sorted({row[1] for row in entries.values()})
    raw = subprocess.check_output(['git', '-C', str(clone), 'cat-file', '--batch'], input=''.join(oid + '\n' for oid in oids).encode())
    blobs, offset = {}, 0
    while offset < len(raw):
        end = raw.index(b'\n', offset)
        oid, kind, size = raw[offset:end].decode().split()
        body = raw[end + 1:end + 1 + int(size)]
        assert kind == 'blob' and hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == oid
        blobs[oid] = body
        offset = end + 1 + int(size) + 1
    source = {}
    for name, (mode, oid, size) in entries.items():
        body = blobs[oid]
        expected = ({'kind': 'symlink', 'target': os.fsdecode(body)} if mode == '120000' else
                    {'kind': 'file', 'bytes': len(body), 'sha256': digest(body)})
        assert manifest[name] == expected and len(body) == size
        source[name] = body
    fixture_sizes[pack['id']] = {'entries': len(entries), 'bytes': sum(v[2] for v in entries.values()), 'manifest_sha256': digest(encode(manifest))}
    questions = {q['id']: q for q in pack['questions']}
    lineage, pending, replayed, fixture_events, origins = {}, None, [], set(), set()
    for event in map(json.loads, (journal / 'events.jsonl').read_text().splitlines()):
        request, value = event['request'], load(event['response'])
        kind = request['event']
        if kind in {'fixture_pinned', 'fixture_before', 'fixture_after'}:
            assert value == manifest and kind not in fixture_events
            fixture_events.add(kind)
        elif kind in {'origin_start', 'origin_end'}:
            assert value['attocode_intel'] == '__init__.py'
            assert all('packages/code-intel/src/attocode_intel/' + p in PROOF['report']['identity']['files'] for p in value.values())
            origins.add(kind)
        elif kind == 'source_lineage':
            key = tuple(request['identity'])
            if value['producer'] != 'metadata':
                assert digest(source[key[0]]) == value['source_sha256']
            lineage[key] = value
        elif kind == 'mcp_response':
            assert pending is None or not replayed
            assert value['isError'] is False and request['tool'] == 'semantic_search'
            page = json.loads(value['content'][0]['text'])
            pending = (request, event['response'], page, lineage)
            lineage = {}
        elif kind == 'validated_page':
            req, ref, page, producer = pending
            row = observation['pages'][len(replayed)]
            assert row == value and row['response_ref'] == ref and row['arguments'] == req['arguments']
            q = questions[row['question']]
            found = visible = False
            for hit in page['data']['results']:
                key = tuple(hit.get(k) for k in ('file_path', 'name', 'chunk_type', 'line', 'end_line'))
                policy = producer[key]
                first, last = hit.get('snippet_start_line'), hit.get('snippet_end_line')
                if first is None and last is None:
                    assert policy['producer'] == 'metadata' or not hit.get('snippet')
                    spans = []
                else:
                    errors, newlines = policies[policy['producer']]
                    assert (policy['errors'], policy['newlines']) == (errors, newlines)
                    text = source[hit['file_path']].decode('utf-8', errors=errors)
                    if newlines == 'universal':
                        text = text.replace('\r\n', '\n').replace('\r', '\n')
                    lines = text.splitlines(keepends=True)
                    offsets = [0]
                    for line in lines:
                        offsets.append(offsets[-1] + len(line))
                    assert all(type(n) is int for n in (hit['line'], hit['end_line'], first, last))
                    assert 1 <= hit['line'] <= first <= last <= hit['end_line'] <= len(lines)
                    snippet = hit['snippet']
                    assert isinstance(snippet, str) and snippet
                    window, spans = text[offsets[first - 1]:offsets[last]], []
                    at = window.find(snippet)
                    while at >= 0:
                        begin, end = offsets[first - 1] + at, offsets[first - 1] + at + len(snippet)
                        if begin < offsets[first] and end > offsets[last - 1]:
                            spans.append((begin, end))
                        at = window.find(snippet, at + 1)
                    assert spans
                if hit['file_path'] == q['file']:
                    found = True
                    if spans and q['anchors']:
                        assert all(lines[a['line'] - 1].rstrip('\r\n') == a['quote'] for a in q['anchors'])
                        anchors = [(offsets[a['line'] - 1], len(a['quote'])) for a in q['anchors']]
                        visible |= any(all(a <= pos and pos + size <= b for pos, size in anchors) for a, b in spans)
            assert row['judgment'] == {'file': found, 'visible': visible}
            assert row['identity'] == [{k: h.get(k) for k in ('file_path', 'name', 'chunk_type', 'score', 'line', 'end_line')} for h in page['data']['results']]
            assert row['data_sha256'] == digest(encode(page['data']))
            args = row['arguments']
            assert args['query'] == q['query'] and row['kind'] == q['kind'] and row['split'] == q['split']
            key = (pack['id'], row['round'], row['question'], args['top_k'], args['max_tokens'], args['file_filter'])
            assert row['arm'] not in pairs.setdefault(key, {})
            pairs[key][row['arm']] = row
            if not args['file_filter']:
                timing[row['arm']].append(row['milliseconds'])
            replayed.append(row)
            pending = None
            checked += 1
    expected = [(r, arm, q['id'], depth, budget, scope) for r, arms in enumerate(design['rounds']) for arm in arms
                for q in pack['questions'] for depth, budget, scope in
                [(d, b, '') for d in (5, 24) for b in (2000, 8000)] + [(5, 2000, q['file'])]]
    actual = [(r['round'], r['arm'], r['question'], r['arguments']['top_k'], r['arguments']['max_tokens'], r['arguments']['file_filter']) for r in replayed]
    assert actual == expected and fixture_events == {'fixture_pinned', 'fixture_before', 'fixture_after'} and origins == {'origin_start', 'origin_end'}

losses, controls, identities, gains = [], [], [], {}
for key, arms in pairs.items():
    assert set(arms) == {'baseline', 'candidate'}
    old, new = arms['baseline'], arms['candidate']
    losses += [{'key': list(key), 'metric': m} for m in ('file', 'visible') if old['judgment'][m] and not new['judgment'][m]]
    if old['identity'] != new['identity']:
        identities.append(list(key))
    if new['kind'] in {'exact', 'unrelated'} and old['data_sha256'] != new['data_sha256']:
        controls.append(list(key))
    if new['kind'] == 'behavior' and key[3] == 5 and not key[5] and new['judgment']['visible'] and not old['judgment']['visible']:
        gains.setdefault(f'{key[1]}:{new["split"]}', set()).add((key[0], key[2]))
p95 = {arm: sorted(v)[math.ceil(.95 * len(v)) - 1] for arm, v in timing.items()}
decision = json.loads((EVIDENCE / 'decision.json').read_bytes())
assert checked == 720 and len(pairs) == decision['pairs'] == 360
assert decision['losses'] == losses and decision['control_changes'] == controls and decision['identity_changes'] == identities
assert not gains and decision['gain_gate'] is False and decision['warm_p95_ms'] == p95
assert decision['latency_gate'] == (p95['candidate'] <= max(100, 1.5 * p95['baseline']))
assert decision['status'] == 'complete' and decision['decision'] == 'reject'
verdict = {'outcome': 'passed', 'head': HEAD, 'run': 39888662258, 'decision': 'reject', 'pages': checked,
           'pairs': len(pairs), 'fixture_sizes': fixture_sizes, 'losses': len(losses), 'control_changes': len(controls),
           'identity_changes': len(identities), 'distinct_gains': 0, 'warm_p95_ms': p95,
           'operator_sha256': digest(Path(__file__).read_bytes())}
(ATTEMPT / 'semantic-admission.json').write_bytes(encode(verdict))
print(json.dumps(verdict))
