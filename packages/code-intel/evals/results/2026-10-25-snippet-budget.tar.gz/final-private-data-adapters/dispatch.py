"""Dispatch a named authorized attempt once; refuse duplicate request files."""
import argparse,json,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('experiment');p.add_argument('label');a=p.parse_args();root=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert branch=='fix/search-snippet-budget' and not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/eren23/attocode/'+path],timeout=45))
assert api('branches/'+branch)['commit']['sha']==head
request=root/(a.label+'-request.json');assert not request.exists();old={r['id'] for r in api('actions/workflows/intelligence-experiments.yml/runs?per_page=100')['workflow_runs']}
request.write_text(json.dumps({'experiment':a.experiment,'head':head,'branch':branch,'previous_run_ids':sorted(old),'created_unix':time.time()},indent=2)+'\n')
subprocess.run(['gh','workflow','run','intelligence-experiments.yml','--repo','eren23/attocode','--ref',branch,'-f','experiment='+a.experiment],check=True,timeout=45)
for _ in range(12):
 rows=[r for r in api('actions/workflows/intelligence-experiments.yml/runs?per_page=100')['workflow_runs'] if r['id'] not in old and r['head_sha']==head and r['event']=='workflow_dispatch']
 if rows:
  assert len(rows)==1;r=rows[0];(root/(a.label+'-dispatch.json')).write_text(json.dumps({'run':r,'observed_unix':time.time()},indent=2)+'\n');print(json.dumps({k:r[k] for k in ('id','head_sha','status','html_url')}));break
 time.sleep(2)
else:raise RuntimeError('request sent; metadata unavailable; do not redispatch')
