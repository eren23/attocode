"""Verify retained evidence arithmetic only; no product code/network."""
import hashlib, io, json, pathlib, xml.etree.ElementTree as ET, zipfile
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected, name
with zipfile.ZipFile(io.BytesIO((root/'runner-artifact.zip').read_bytes())) as z:
    decision=json.loads(z.read('decision.json'))
    partial=json.loads(z.read('pandas.json'))
    assert decision['status']=='incomplete' and decision['cleanup_verified'] and decision['identities_unchanged']
    assert decision['budget_violation'] is None
    assert len(partial['pages'])==13 and {r['arm'] for r in partial['pages']}=={'baseline'}
    assert {r['question'] for r in partial['pages']}=={'p1','p2','p3'}
    for phase, failures in [('baseline',2),('candidate',0)]:
        cases=ET.fromstring(z.read(phase+'.xml')).findall('.//testcase')
        assert len(cases)==13 and sum(c.find('failure') is not None for c in cases)==failures
        assert not any(c.find('error') is not None or c.find('skipped') is not None for c in cases)
print(json.dumps({'status':'incomplete','quality_verdict':None,'baseline_pages':13,'candidate_pages':0,'rerun':False}))
