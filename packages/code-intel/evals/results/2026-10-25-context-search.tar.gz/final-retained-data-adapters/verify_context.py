"""Independent retained-data replay: stdlib/Git/blob reads, no tested imports/execution."""
import ast,hashlib,importlib.util,json,math,os,pathlib,stat,subprocess,sys,zipfile,zlib
from collections import deque
R=pathlib.Path(__file__).parent
POLICIES={'body_index':('replace','universal'),'hydrated_metadata':('strict','raw'),'exact_scoped_source':('replace','raw')}
def check(value,message):
 if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
ARCHIVE_ROOT=None
ARCHIVE_MEMBERS=None
def evidence_bytes(p):
 p=pathlib.Path(p)
 if ARCHIVE_ROOT is not None:
  relative=p.relative_to(ARCHIVE_ROOT).as_posix()
  check(relative in ARCHIVE_MEMBERS and p.is_file() and not p.is_symlink(), 'consumed evidence is not an original regular ZIP member')
  check(p.resolve()==ARCHIVE_ROOT.resolve()/relative, 'evidence parent symlink')
 return p.read_bytes()
def read(p):return json.loads(evidence_bytes(p))
def git(*args):return subprocess.check_output(['git',*args],env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'})
def canonical(data,workspace):
 result=json.loads(json.dumps(data));index=result.get('ranking',{}).get('index')
 if isinstance(index,dict):
  for k in ('warmup_seconds','keyword_seconds','importance_seconds','body_seconds'):index.pop(k,None)
 follow=result.get('follow_up',{});args=follow.get('arguments',{}) if isinstance(follow,dict) else {}
 if 'workspace' in args:
  check(args['workspace']==workspace,'wrong physical continuation workspace');args['workspace']='__quality_fixture_workspace__'
 return result

def engine_manifest(commit):
 prefix='packages/code-intel/src/attocode_intel/'
 names=git('ls-tree','-r','--name-only',commit,'--',prefix).decode().splitlines()
 return {n.removeprefix(prefix):sha(git('show',commit+':'+n)) for n in names}

def fixture(spec,head):
 s=importlib.util.spec_from_file_location('private_cached_source_reader',R/'source_reader.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 original,entries,history=m.inventory(spec['id'])
 for k in ('repo','commit','include','subdir'):check(spec.get(k)==original.get(k),'fixture recipe changed')
 code=git('show',head+':packages/code-intel/src/attocode_intel/_internal/integrations/context/codebase_context.py')
 skips={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(code).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('SKIP_EXTENSIONS','SKIP_FILENAMES')}
 selected={}
 for full,(mode,oid,size) in entries.items():
  name=full
  if spec.get('subdir'):
   if not name.startswith(spec['subdir']+'/'):continue
   name=name[len(spec['subdir'])+1:]
  if spec.get('include') and not any(name==p or name.startswith(p+'/') for p in spec['include']):continue
  if mode=='120000' or (mode in ('100644','100755') and size<=1000000 and pathlib.Path(name).suffix.lower() not in skips['SKIP_EXTENSIONS'] and pathlib.Path(name).name not in skips['SKIP_FILENAMES']):selected[name]=(mode,oid,size)
 bodies={}
 if not history:
  oids=sorted({v[1] for v in selected.values()});packet=subprocess.check_output(['git','-C',str(m.C/spec['id']),'cat-file','--batch'],input=''.join(x+'\n' for x in oids).encode(),env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'});offset=0
  for oid in oids:
   end=packet.index(b'\n',offset);fields=packet[offset:end].decode().split();check(len(fields)==3 and fields[:2]==[oid,'blob'],'missing existing pinned blob');size=int(fields[2]);bodies[oid]=packet[end+1:end+1+size];offset=end+size+2
  check(offset==len(packet),'Git batch suffix differs')
 receipt={};contents={}
 for name,(mode,oid,size) in selected.items():
  raw=zlib.decompress((m.H/'blobs'/oid[:2]/oid[2:]).read_bytes()) if history else bodies[oid]
  check(len(raw)==size and hashlib.sha1(b'blob '+str(size).encode()+b'\0'+raw).hexdigest()==oid,'pinned Git blob hash differs')
  receipt[name]={'kind':'symlink','target':os.fsdecode(raw)} if mode=='120000' else {'kind':'file','bytes':size,'sha256':sha(raw)};contents[name]=raw
 tree=subprocess.check_output(['git','-C',str(m.C/spec['id']),'rev-parse',spec['commit']+'^{tree}'],env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'}).decode().strip()
 check(len(tree)==40 and all(c in '0123456789abcdef' for c in tree),'invalid pinned tree')
 return receipt,contents,tree

def resolve(receipt,name):
 check(isinstance(name,str) and name and len(name)<4097 and not name.startswith('/'),'unsafe fixture path')
 todo=deque(name.split('/'));parts=[];seen=set();links=0
 while todo:
  state=(tuple(parts),tuple(todo));check(state not in seen,'cyclic source alias');seen.add(state)
  part=todo.popleft()
  if part in ('','.'):continue
  if part=='..':check(parts,'source leaves fixture');parts.pop();continue
  path='/'.join([*parts,part]);entry=receipt.get(path)
  if entry and entry['kind']=='symlink':
   links+=1;target=entry['target'];check(links<=40 and target and not target.startswith('/') and len(target)<4097,'invalid alias');todo=deque([*target.split('/'),*todo])
  elif entry and entry['kind']=='file':check(not todo,'file traversed as directory');return path
  else:check(todo and any(p.startswith(path+'/') for p in receipt),'missing source path');parts.append(part)
 raise ValueError('source alias lacks file target')

def blob(root,ref):
 check(isinstance(ref,dict) and type(ref.get('bytes')) is int and ref['path']=='blobs/'+ref['sha256']+'.json','invalid raw reference')
 raw=evidence_bytes(root/ref['path']);check(len(raw)==ref['bytes'] and sha(raw)==ref['sha256'],'raw bytes differ');return json.loads(raw)
def source_judgment(page,policies,question,receipt,contents):
 files=set();visible=set()
 for hit in page['data']['results']:
  path=hit['file_path'];key=(path,hit.get('name'),hit.get('chunk_type'),hit.get('line'),hit.get('end_line'));policy=policies[key]
  raw=contents[resolve(receipt,path)]
  for i,e in enumerate(question['evidence']):
   if path==e['file']:files.add(path)
  if hit.get('snippet_start_line') is None and hit.get('snippet_end_line') is None:
   check(policy['producer']=='metadata' or not hit.get('snippet'),'source text lacks coordinates');continue
  check(policy['producer'] in POLICIES,'unknown source producer')
  errors,newlines=POLICIES[policy['producer']];check((policy['errors'],policy['newlines'])==(errors,newlines) and policy['source_sha256']==sha(raw),'source policy/hash differs')
  text=raw.decode('utf-8',errors=errors)
  if newlines=='universal':text=text.replace('\r\n','\n').replace('\r','\n')
  lines=text.splitlines(keepends=True);start,end,first,last=(hit.get(k) for k in ('line','end_line','snippet_start_line','snippet_end_line'))
  check(all(type(n)is int for n in (start,end,first,last)) and 1<=start<=first<=last<=end<=len(lines),'source coordinates invalid')
  offsets=[0]
  for line in lines:offsets.append(offsets[-1]+len(line))
  snippet=hit['snippet'];check(isinstance(snippet,str) and snippet,'empty source excerpt');window=''.join(lines[first-1:last]);found=window.find(snippet);spans=[]
  while found>=0:
   lo=offsets[first-1]+found;hi=lo+len(snippet)
   if lo<offsets[first] and hi>offsets[last-1]:spans.append((lo,hi))
   found=window.find(snippet,found+1)
  check(spans,'excerpt is not pinned source')
  for i,e in enumerate(question['evidence']):
   if e['file']!=path:continue
   pos=offsets[e['line']-1]+lines[e['line']-1].index(e['quote'])
   if any(a<=pos and pos+len(e['quote'])<=b for a,b in spans):visible.add(i)
 return {'files':sorted(files),'visible':sorted(visible)}

def replay_role(folder,spec,protocol,receipt,contents,engine,role,pids,workspace):
 observation=read(folder/'pages.json');check(observation['status']=='complete' and observation['arm']==role and observation['pack']==spec['id'] and observation['rounds_completed']==3,'worker incomplete')
 pid=observation['pid'];check(type(pid)is int and pid>0 and pid not in pids,'worker PID reused');pids.add(pid)
 journal=folder/'journal';policies={};pending=None;ctx_pending=None;pages=[];state=[];ready=False;semantic=False;graphs=set();contexts=set()
 expected=[]
 for n in range(3):
  for q in spec['questions']:
   for d,b,s in grid(q,protocol):
    args={'query':q['query'],'top_k':d,'max_tokens':b,'file_filter':s}
    if role=='candidate' and q['context_file']:args['context_file']=q['context_file']
    expected.append((n,q,args))
 for line in evidence_bytes(journal/'events.jsonl').splitlines():
  event=json.loads(line);request=event['request'];value=blob(journal,event['response']);kind=request['event'];check('origin_end' not in state,'event after shutdown')
  if kind in ('origin_start','origin_end'):
   check(kind not in state and value.get('attocode_intel')=='__init__.py','origin binding invalid')
   if kind=='origin_start':check(not state,'late worker origin')
   else:check('gateway_close' in state and 'fixture_after' in state and len(pages)==len(expected),'early final origin')
   for name,path in value.items():check(name.startswith('attocode_intel') and path in engine,'module not in exact engine')
   state.append(kind)
  elif kind in ('fixture_before','fixture_after'):
   check(value==receipt and kind not in state,'fixture source differs')
   check(('origin_start' in state and not pages) if kind=='fixture_before' else ('gateway_close' in state and len(pages)==len(expected)),'fixture identity chronology differs');state.append(kind)
  elif kind=='readiness_initialize':
   check('fixture_before' in state and 'readiness_initialize' not in state and not pages,'invalid initialize order');check(request=={'event':kind,'operation':'search_symbols','arguments':{'name':'__quality_initialize__'}} and not value.get('isError'),'initialize request differs');state.append(kind)
  elif kind=='readiness_poll':
   check('readiness_initialize' in state and not pages and not ready and request=={'event':kind,'operation':'capabilities','arguments':{}},'readiness binding/order differs')
   c=value['structuredContent']['capabilities']['coverage'];ready=c.get('phase')=='ready' and c.get('discovery_truncated') is False and type(c.get('total_files'))is int and c['total_files']>0 and all(type(c.get(k))is int and c[k]>=c['total_files'] for k in ('parsed_files','reference_indexed_files'))
  elif kind=='readiness_semantic':
   check(ready and not semantic and not pages and request['arguments']=={'query':'__quality_body_initialize__','top_k':5,'max_tokens':2000,'file_filter':''},'semantic warmup binding/order differs');check(not value.get('isError'),'warmup failed');index=json.loads(value['content'][0]['text'])['data']['ranking']['index'];semantic=index.get('status')==index.get('warmup_stage')=='ready'
  elif kind in ('context_graph','context_neighborhood'):
   check(role=='candidate' and ready and semantic and pending is None,'unbound graph capture');(graphs if kind=='context_graph' else contexts).add(event['response']['sha256'])
  elif kind=='context_lineage':
   check(ctx_pending is None and role=='candidate' and ready and semantic and pending is None,'unbound context lineage')
   check(value['graph_ref']['sha256'] in graphs and value['context_ref']['sha256'] in contexts,'late or unbound graph snapshots');ctx=blob(journal,value['context_ref']);g=blob(journal,value['graph_ref']);file=value['arguments']['context_file'];check(file==ctx['file']==g['file'],'context file changed')
   neighbors=g['eligible_neighbors'];check(neighbors==sorted(set(neighbors)) and set(neighbors)<=(set(g['imports'])|set(g['importers']))-{file},'invalid observed neighborhood')
   for path in [file,*neighbors]:resolve(receipt,path)
   paths=[file,*neighbors[:31]];relations={p:'context' if p==file else 'imports' if p in g['imports'] else 'importer' for p in paths}
   check(ctx['paths']==paths and ctx['relations']==relations and ctx['omitted_paths']==max(0,len(neighbors)-31) and ctx['applied'] is True and ctx['status']=='ready','context differs from observed unchanged graph');ctx_pending=(value['arguments'],ctx)
  elif kind=='source_lineage':
   check(ready and semantic and pending is None,'late source lineage');key=tuple(request['identity'])
   if value['producer']!='metadata':check(sha(contents[resolve(receipt,key[0])])==value['source_sha256'],'lineage not pinned source')
   policies[key]=value
  elif kind=='preview_input_identity':
   check(ready and semantic and pending is None,'late render input identity')
  elif kind=='mcp_response':
   check(ready and semantic and pending is None and len(pages)<len(expected),'unadmitted previous/extra page');check(request['tool']=='semantic_search' and not value.get('isError'),'MCP error')
   n,q,args=expected[len(pages)];check(request['arguments']==args,'query/scope/budget/context binding differs');page=json.loads(value['content'][0]['text']);ws=page['metadata']['workspace'];check(ws==workspace,'wrong physical fixture role');index=page['data']['ranking']['index'];check(index['status']==index['warmup_stage']=='ready','unready scored search')
   if args.get('context_file'):
    check(ctx_pending is not None,'no actual context lineage');cargs,ctx=ctx_pending;check(cargs=={k:args.get(k,'auto' if k=='mode' else '') for k in ('query','top_k','file_filter','context_file','mode')},'context callback request differs');wire=page['data']['ranking']['context'];check(wire['file']==ctx['file'] and wire['applied'] is True and wire['status']=='ready' and wire['candidate_files']==len(ctx['paths']) and wire['omitted_paths']==ctx['omitted_paths'],'public context differs')
    for hit in page['data']['results']:
     relation=ctx['relations'].get(hit['file_path']);check(hit.get('context_reason')==({'context_file':ctx['file'],'relation':relation} if relation else None),'result relationship differs')
   else:check(ctx_pending is None,'context executed for ordinary search')
   ctx_pending=None
   judgment=source_judgment(page,policies,q,receipt,contents);pending=(n,q,args,event['response'],page,judgment,ws);policies={}
  elif kind=='validated_page':
   check(pending is not None,'summary without original raw response');n,q,args,ref,page,judgment,ws=pending;expected_summary={'pack':spec['id'],'round':n,'arm':role,'question':q['id'],'kind':q['kind'],'arguments':args,'response_ref':ref,'milliseconds':value['milliseconds'],'data_sha256':sha(encoded(page['data'])),'control_sha256':sha(encoded(canonical(page['data'],ws))),'judgment':judgment};check(value==expected_summary,'raw/source-derived page differs');check(type(value['milliseconds'])in(int,float) and math.isfinite(value['milliseconds']) and value['milliseconds']>=0,'invalid elapsed query time');pages.append(value);pending=None
  elif kind=='gateway_close':check(value=={'status':'complete'} and pending is None and ctx_pending is None and len(pages)==len(expected),'shutdown before complete admission');state.append(kind)
  else:raise ValueError('Unknown journal event '+kind)
 check(state==['origin_start','fixture_before','readiness_initialize','gateway_close','fixture_after','origin_end'] and ready and semantic and pending is None and observation['pages']==pages,'incomplete/altered worker capture')
 return pages

def grid(q,p):
 c=p['requests'];return [(d,b,'') for d in c['depths'] for b in c['budgets']]+[(c['scoped_depth'],c['scoped_budget'],path) for path in dict.fromkeys(e['file'] for e in q['evidence'])]
def quality(pages,protocol):
 pairs={};timing={'baseline':[],'candidate':[]};qmap={(p['id'],q['id']):q for p in protocol['packs'] for q in p['questions']}
 for x in pages:
  a=x['arguments'];key=(x['pack'],x['round'],x['question'],a['top_k'],a['max_tokens'],a['file_filter']);check(x['arm'] not in pairs.setdefault(key,{}),'duplicate paired row');pairs[key][x['arm']]=x
  if not a['file_filter'] and qmap[(x['pack'],x['question'])]['context_file'] and x['arm'] in timing:timing[x['arm']].append(x['milliseconds'])
 losses=[];controls=[];gains={n:set() for n in range(3)}
 for k,arms in pairs.items():
  check(set(arms)=={'baseline','candidate_plain','candidate'},'unpaired page');base,plain,new=(arms[a] for a in ('baseline','candidate_plain','candidate'))
  if base['control_sha256']!=plain['control_sha256']:controls.append({'key':k,'role':'candidate_plain'})
  if new['kind']in('exact','unrelated') and base['control_sha256']!=new['control_sha256']:controls.append({'key':k,'role':'candidate'})
  for metric in ('files','visible'):
   missing=set(base['judgment'][metric])-set(new['judgment'][metric])
   if missing:losses.append({'key':k,'metric':metric,'lost':sorted(missing)})
  if k[3]==5 and not k[5] and new['kind']in('implementation','test'):
   for f in set(new['judgment']['files'])-set(base['judgment']['files']):
    if any(e['file']==f and i in new['judgment']['visible'] for i,e in enumerate(qmap[(k[0],k[2])]['evidence'])):gains[k[1]].add((k[0],f))
 check(all(timing.values()),'missing latency samples');p95={a:sorted(v)[math.ceil(.95*len(v))-1] for a,v in timing.items()};gate=all(len(v)>=2 and len({p for p,f in v})>=2 for v in gains.values());latency=p95['candidate']<=max(250,2*p95['baseline'])
 return {'status':'complete','decision':'retain' if gate and latency and not losses and not controls else 'reject','gain_gate':gate,'latency_gate':latency,'losses':losses,'control_changes':controls,'gains_by_round':{str(k):sorted(v) for k,v in gains.items()},'warm_p95_ms':p95,'pairs':len(pairs),'qualification':'Optional context adds supplied task information; non-exhaustive source labels, not default-ranking or agent-outcome evidence.'}

LIMITS={'seconds':600,'disk_bytes':2**31,'rss_bytes':2**31,'evidence_bytes':64*2**20}
ROOTS=['eval','packages/code-intel','pyproject.toml','uv.lock','.github/workflows/intelligence-experiments.yml']
def input_manifest(head):
 names=git('ls-tree','-r','--name-only',head,'--',*ROOTS).decode().splitlines()
 return {n:sha(git('show',head+':'+n)) for n in names}
def run_resources(run,outer):
 check(run['status']=='completed' and run['conclusion']=='success' and type(run['run_attempt'])is int and run['run_attempt']==1 and run['event']=='workflow_dispatch' and run['path']=='.github/workflows/intelligence-experiments.yml','run identity invalid')
 check(type(run['id'])is int and outer['identity']['commit']==run['head_sha'] and outer['identity']['github_run_id']==str(run['id']),'run/report source binding differs')
 check(outer['experiment']=='context_search' and outer['status']=='complete' and outer['decision'] is None and outer['cleanup_verified'] is True and outer['owned_scratch_removed'] is True and outer['limits']==LIMITS,'outer completion/limit differs')
 check(type(outer['seconds'])in(int,float) and math.isfinite(outer['seconds']) and 0<=outer['seconds']<600,'stage elapsed exceeds bound')
 t=outer['supervision'];check(t['status']=='passed' and type(t['exit_code'])is int and t['exit_code']==0 and t['cleanup_verified'] is True and t['log_truncated'] is False and t.get('cleanup_errors',[])==[],'supervision failed')
 for key,limit in [('peak_rss_bytes',2**31),('peak_disk_bytes',2**31),('peak_evidence_bytes',64*2**20)]:
  check(type(t[key])is int and 0<=t[key]<limit,'resource cap differs')
def frozen_protocol(p):
 check(p['rounds']==[['baseline','candidate_plain','candidate'],['candidate','candidate_plain','baseline'],['baseline','candidate_plain','candidate']],'rounds changed')
 check(p['requests']=={'depths':[5,24],'budgets':[2000,8000],'scoped_depth':5,'scoped_budget':8000} and p['limits']==LIMITS,'settings/limits changed')
 check(p['gates']=={'distinct_file_and_visible_gains_at_5_each_round':2,'repositories_with_gains_each_round':2,'individual_file_or_visible_losses':0,'noncontext_control_changes':0,'warm_p95_floor_ms':250,'warm_p95_ratio':2},'quality gates changed')
def validation_gate(config,protocol,protocol_sha,head,current):
 stage=config['stage'];check(stage in ('development','validation'),'unknown stage')
 if stage=='development':check('development_admission' not in config,'development has prior gate');return
 gate=config['development_admission'];path=pathlib.PurePosixPath(gate['path']);check(not path.is_absolute() and '..' not in path.parts and str(path).startswith('packages/code-intel/evals/results/'),'unsafe gate path')
 raw=git('show',head+':'+str(path));check(len(raw)<4*2**20 and sha(raw)==gate['sha256'],'development proof hash differs');proof=json.loads(raw)
 check(proof['outcome']=='passed' and proof['stage']=='development' and proof['public_design_sha256']==protocol_sha and proof['baseline_commit']==protocol['baseline_commit'] and proof['candidate_sha256']==protocol['candidate_sha256'],'development source/protocol differs')
 run_resources(proof['run'],proof['report']);check(proof['all_archive_extracted_bytes_equal'] is True and proof['all_raw_source_origin_order_replayed'] is True,'development raw/source admission missing')
 decision=proof['decision'];check(decision['status']=='complete' and decision['decision']=='retain' and decision['gain_gate'] is True and decision['latency_gate'] is True and decision['losses']==[] and decision['control_changes']==[],'development did not pass')
 for key in ('archive_sha256','operator_sha256'):
  value=proof[key];check(type(value)is str and len(value)==64 and all(c in '0123456789abcdef' for c in value),'development lacks byte identity')
 oldhead=proof['run']['head_sha'];old=input_manifest(oldhead);check(proof['report']['identity']['files']==old,'development inputs differ from Git')
 oldconfig=json.loads(git('show',oldhead+':eval/quality/experiments/context_search.json'));check(oldconfig['stage']=='development' and oldconfig['design_sha256']==protocol_sha and 'development_admission' not in oldconfig,'gate did not originate in development')
 mutable={'eval/quality/experiments/context_search.json',str(path)}
 check({k:v for k,v in old.items() if k not in mutable}=={k:v for k,v in current.items() if k not in mutable},'inputs changed after development')
 # Require the exact retained independent development admission, not a hand-authored equivalent.
 local=R/'development-2-import-repair'/'semantic-admission.json';check(local.is_file() and local.read_bytes()==raw,'committed gate is not retained independent development admission')
def verify_engines(freeze,engines,protocol):
 check(set(engines)=={'baseline','candidate'} and freeze['engines']==engines and engines['candidate']==protocol['candidate_engine_files'] and sha(encoded(engines['candidate']))==protocol['candidate_sha256'],'engine bytes differ')
 return {**engines,'candidate_plain':engines['candidate']}
def verify(attempt):
 global ARCHIVE_ROOT,ARCHIVE_MEMBERS
 attempt=attempt.absolute();ARCHIVE_ROOT=None;ARCHIVE_MEMBERS=None
 proof=read(attempt/'admission.json');check(proof['outcome']=='passed','incomplete original attempt');run=proof['run'];head=run['head_sha'];raw=(attempt/'artifact.zip').read_bytes();check(sha(raw)==proof['archive_sha256']==proof['artifact']['digest'].removeprefix('sha256:'),'original archive digest differs')
 check(len(raw)<64*2**20 and proof['artifact']['workflow_run']['id']==run['id'] and proof['artifact']['workflow_run']['head_sha']==head and proof['artifact']['expired'] is False and proof['artifact']['name']=='experiment-context_search-'+str(run['id'])+'-1','artifact binding differs')
 with zipfile.ZipFile(attempt/'artifact.zip') as z:
  members={m.filename for m in z.infolist() if not m.is_dir()};check(len(z.infolist())==len({m.filename for m in z.infolist()}) and sum(m.file_size for m in z.infolist())<64*2**20,'duplicate/oversize archive')
  for m in z.infolist():
   path=pathlib.PurePosixPath(m.filename);check(not path.is_absolute() and '..' not in path.parts and not stat.S_ISLNK(m.external_attr>>16),'unsafe original archive path')
   if not m.is_dir():check(not (attempt/m.filename).is_symlink() and (attempt/m.filename).read_bytes()==z.read(m),'extracted bytes differ')
 ARCHIVE_ROOT=attempt;ARCHIVE_MEMBERS=members
 reports=[attempt/n for n in members if pathlib.PurePosixPath(n).name=='report.json'];check(len(reports)==1,'ambiguous attempt report');outer=read(reports[0]);check(outer==proof['report'],'outer report differs');run_resources(run,outer)
 current=input_manifest(head);check(current==outer['identity']['files'],'source identity differs from Git')
 evidence=reports[0].parent/'context';freeze=read(evidence/'freeze.json');protocol_raw=git('show',head+':packages/code-intel/evals/designs/2026-10-25-context-search.json');protocol=json.loads(protocol_raw);config_raw=git('show',head+':eval/quality/experiments/context_search.json');config=json.loads(config_raw);stage=config['stage'];check(config['limits']==LIMITS and sha(config_raw)==outer['identity']['design_sha256'] and config['design_sha256']==sha(protocol_raw)==freeze['design_sha256'] and freeze['head']==head and freeze['baseline']==protocol['baseline_commit'],'frozen protocol/source differs')
 frozen_protocol(protocol);validation_gate(config,protocol,sha(protocol_raw),head,current)
 engines={a:engine_manifest(c) for a,c in [('baseline',protocol['baseline_commit']),('candidate',head)]};verify_engines(freeze,engines,protocol)
 check({k:v for k,v in engines['candidate'].items() if k.endswith('.py')}==protocol['candidate_runtime_files'],'runtime map differs')
 changed=sorted(k for k in engines['baseline'].keys()|engines['candidate'].keys() if engines['baseline'].get(k)!=engines['candidate'].get(k));check(freeze['changed_engine_files']==changed,'changed engine list differs');engines['candidate_plain']=engines['candidate']
 command=outer['supervision']['command'];check(command[1:5]==['-m','eval.quality.experiments','context_search','--root'] and command[-1]=='--payload' and len(command)==7,'payload command differs');work=pathlib.PurePosixPath(command[5])/'work/context'
 for name in ('controller-origin.json','controller-complete.json'):
  record=read(reports[0].parent/name)
  for module,path in record['origins'].items():check(module.startswith('attocode_intel') and path in engines['candidate'],'controller origin differs')
  if name=='controller-complete.json':check(record['complete'] is True,'controller incomplete')
 allpages=[];pids=set()
 for p in protocol['packs']:
  spec={**p,'questions':[q for q in p['questions'] if q['split']==stage]};dest=evidence/p['id'];receipt,contents,tree=fixture(spec,head);meta=read(dest/'fixture.json');check(meta['tree']==tree and meta['receipt']==receipt and meta['repo']==spec['repo'] and meta['commit']==spec['commit'],'pinned receipt differs')
  for q in spec['questions']:
   for label in q['evidence']:
    text=contents[resolve(receipt,label['file'])].decode();check(text.splitlines()[label['line']-1].strip()==label['quote'].strip() and sha(contents[resolve(receipt,label['file'])])==label['source_sha256'],'question source differs')
   if q['context_file']:check(q['context_file'] not in {e['file'] for e in q['evidence']} and sha(contents[resolve(receipt,q['context_file'])])==spec['source_sha256'][q['context_file']],'context supplies answer or changed')
  roles={a:replay_role(dest/a,spec,protocol,receipt,contents,engines[a],a,pids,str(work/(spec['id']+'-'+a))) for a in ('baseline','candidate_plain','candidate')};combined=read(dest/'combined.json');ordered=[]
  for n,arms in enumerate(protocol['rounds']):
   for arm in arms:ordered.extend(row for row in roles[arm] if row['round']==n)
  check(combined=={'pack':p['id'],'status':'complete','pages':ordered},'combined order differs');allpages.extend(ordered)
 decision=quality(allpages,protocol);check(json.loads(json.dumps(decision))==read(evidence/'decision.json'),'independent decision differs')
 result={'outcome':'passed','stage':stage,'public_design_sha256':sha(protocol_raw),'baseline_commit':protocol['baseline_commit'],'candidate_sha256':protocol['candidate_sha256'],'run':run,'report':outer,'decision':decision,'archive_sha256':sha(raw),'operator_sha256':sha(pathlib.Path(__file__).read_bytes()),'all_archive_extracted_bytes_equal':True,'all_raw_source_origin_order_replayed':True,'raw_scored_pages':len(allpages),'fresh_worker_pids':sorted(pids),'local_product_operator_execution':False,'limitations':'Token budget counting is source-bound online admission. Resolved graph edges/eligibility are observations of unchanged source-bound AST graph, not independent compiler resolution or complete absence proof.'}
 (attempt/'semantic-admission.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'outcome':'passed','stage':stage,'pages':len(allpages),'workers':len(pids),'decision':decision}))
if __name__=='__main__':verify(pathlib.Path(sys.argv[1]))
