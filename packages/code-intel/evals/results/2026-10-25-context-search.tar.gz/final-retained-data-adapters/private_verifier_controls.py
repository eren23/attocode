"""Private stdlib data-only adversarial checks. No public operator/product imports."""
import copy,importlib.util,json,pathlib,tempfile
R=pathlib.Path(__file__).parent
sp=importlib.util.spec_from_file_location('private_context_replay',R/'verify_context.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
passed=[]
def okay(name,fn):fn();passed.append(name)
def reject(name,fn):
 try:fn()
 except (ValueError,KeyError,TypeError,IndexError):passed.append(name);return
 raise AssertionError('accepted '+name)
p=json.loads(pathlib.Path('packages/code-intel/evals/designs/2026-10-25-context-search.json').read_bytes())
okay('frozen_protocol',lambda:v.frozen_protocol(p))
for key in ('rounds','requests','limits','gates'):
 d=copy.deepcopy(p);d[key]={};reject('changed_'+key,lambda:v.frozen_protocol(d))
e={'baseline':{'old':'0'*64},'candidate':{'new':'1'*64}};d={'candidate_engine_files':e['candidate'],'candidate_sha256':v.sha(v.encoded(e['candidate']))}
okay('physical_two_engine_freeze',lambda:v.verify_engines({'engines':e},e,d))
bad=copy.deepcopy(e);bad['candidate_plain']=e['candidate'];reject('three_role_freeze',lambda:v.verify_engines({'engines':bad},e,d))
okay('canonical_duration_only',lambda: v.check(v.canonical({'ranking':{'index':{'warmup_seconds':10,'other':2}},'follow_up':{'arguments':{'workspace':'/right'}}},'/right')=={'ranking':{'index':{'other':2}},'follow_up':{'arguments':{'workspace':'__quality_fixture_workspace__'}}},'canonical wrong'))
reject('wrong_physical_workspace',lambda:v.canonical({'follow_up':{'arguments':{'workspace':'/wrong'}}},'/right'))
receipt={'a':{'kind':'symlink','target':'b'},'b':{'kind':'file'},'cycle':{'kind':'symlink','target':'cycle'},'escape':{'kind':'symlink','target':'../outside'}}
okay('component_alias',lambda:v.check(v.resolve(receipt,'a')=='b','alias wrong'))
for name in ('cycle','escape','/b','b/child','missing'):
 reject('bad_alias_'+name,lambda:v.resolve(receipt,name))
with tempfile.TemporaryDirectory(prefix='context-private-data-') as folder:
 root=pathlib.Path(folder);(root/'present').write_bytes(b'{}');(root/'planted').write_bytes(b'{}');v.ARCHIVE_ROOT=root;v.ARCHIVE_MEMBERS={'present'}
 okay('archive_member_read',lambda:v.read(root/'present'))
 reject('planted_nonmember',lambda:v.read(root/'planted'))
 v.ARCHIVE_MEMBERS.add('alias');(root/'alias').symlink_to(root/'present');reject('symlink_member',lambda:v.read(root/'alias'))
v.ARCHIVE_ROOT=v.ARCHIVE_MEMBERS=None
proof=json.loads((R/'qualification-green-1/admission.json').read_bytes());run=copy.deepcopy(proof['run']);outer=copy.deepcopy(proof['report']);outer['experiment']='context_search'
okay('run_resource_binding',lambda:v.run_resources(run,outer))
for field,value in [('run_attempt',True),('event','push'),('status','in_progress'),('conclusion','failure')]:
 bad=copy.deepcopy(run);bad[field]=value;reject('bad_run_'+field,lambda:v.run_resources(bad,outer))
for field,value in [('seconds',float('nan')),('seconds',600),('cleanup_verified',False),('owned_scratch_removed',False)]:
 bad=copy.deepcopy(outer);bad[field]=value;reject('bad_outer_'+field,lambda:v.run_resources(run,bad))
for field,value in [('peak_rss_bytes',2**31),('peak_disk_bytes',True),('peak_evidence_bytes',64*2**20),('exit_code',True),('log_truncated',True)]:
 bad=copy.deepcopy(outer);bad['supervision'][field]=value;reject('bad_supervision_'+field,lambda:v.run_resources(run,bad))
okay('development_no_gate',lambda:v.validation_gate({'stage':'development'},p,'0'*64,'unused',{}))
reject('development_prior_gate',lambda:v.validation_gate({'stage':'development','development_admission':{}},p,'0'*64,'unused',{}))
for path in ('/absolute','../escape','docs/gate.json'):
 reject('unsafe_validation_gate_'+path,lambda:v.validation_gate({'stage':'validation','development_admission':{'path':path}},p,'0'*64,'unused',{}))
# Synthetic paired data: independent quality math; no corpus queries or public fixtures.
protocol={'requests':p['requests'],'packs':[]};pages=[]
for pack in ('one','two'):
 q={'id':'q','context_file':'caller.py','evidence':[{'file':pack+'.py'}]};protocol['packs'].append({'id':pack,'questions':[q]})
 for n in range(3):
  for arm in ('baseline','candidate_plain','candidate'):
   for depth,budget,scope in v.grid(q,protocol):
    pages.append({'pack':pack,'round':n,'arm':arm,'question':'q','kind':'implementation','arguments':{'top_k':depth,'max_tokens':budget,'file_filter':scope},'milliseconds':1,'control_sha256':'a','judgment':{'files':[pack+'.py'] if arm=='candidate' else [],'visible':[0] if arm=='candidate' else []}})
okay('distinct_two_repo_gains',lambda:v.check(v.quality(pages,protocol)['decision']=='retain','quality wrong'))
bad=copy.deepcopy(pages);bad[1]['control_sha256']='changed';okay('ordinary_payload_drift_reject',lambda:v.check(v.quality(bad,protocol)['decision']=='reject','drift accepted'))
bad=copy.deepcopy(pages);bad.append(copy.deepcopy(bad[0]));reject('duplicate_pair',lambda:v.quality(bad,protocol))
bad=copy.deepcopy(pages);bad.pop();reject('missing_pair',lambda:v.quality(bad,protocol))
bad=copy.deepcopy(pages)
for row in bad:
 if row['arm']=='candidate':row['judgment']['visible']=[]
okay('no_visible_gains_reject',lambda:v.check(v.quality(bad,protocol)['decision']=='reject','invisible gain accepted'))
(R/'private-verifier-controls.json').write_text(json.dumps({'passed':len(passed),'checks':passed,'public_product_or_operator_execution':False},indent=2)+'\n');print('PASS',len(passed),'private retained/synthetic data checks')
# Independent validation admission must bind exact local development proof and frozen Git input map.
old_R,old_git,old_manifest=v.R,v.git,v.input_manifest
with tempfile.TemporaryDirectory(prefix='context-private-gate-') as folder:
 v.R=pathlib.Path(folder);(v.R/'development-2-import-repair').mkdir()
 oldfiles={'engine.py':'1'*64,'eval/quality/experiments/context_search.json':'old'}
 newfiles={**oldfiles,'eval/quality/experiments/context_search.json':'new','packages/code-intel/evals/results/gate.json':'proof'}
 dev=copy.deepcopy(proof);dev.update(outcome='passed',stage='development',public_design_sha256='0'*64,baseline_commit=p['baseline_commit'],candidate_sha256=p['candidate_sha256'],all_archive_extracted_bytes_equal=True,all_raw_source_origin_order_replayed=True,archive_sha256='1'*64,operator_sha256='2'*64)
 dev['report']=copy.deepcopy(outer);dev['report']['identity']['files']=oldfiles
 dev['decision']={'status':'complete','decision':'retain','gain_gate':True,'latency_gate':True,'losses':[],'control_changes':[]}
 def setup_gate(value):
  raw=json.dumps(value).encode();(v.R/'development-2-import-repair/semantic-admission.json').write_bytes(raw)
  config={'stage':'validation','development_admission':{'path':'packages/code-intel/evals/results/gate.json','sha256':v.sha(raw)}}
  def fake_git(*args):
   if args[-1].endswith(':packages/code-intel/evals/results/gate.json'):return raw
   if args[-1].endswith(':eval/quality/experiments/context_search.json'):return json.dumps({'stage':'development','design_sha256':'0'*64}).encode()
   raise AssertionError(args)
  v.git=fake_git;v.input_manifest=lambda h:oldfiles
  return config
 config=setup_gate(dev)
 okay('validation_exact_gate_and_inputs',lambda:v.validation_gate(config,p,'0'*64,'new',newfiles))
 badfiles={**newfiles,'engine.py':'changed'};reject('validation_engine_drift',lambda:v.validation_gate(config,p,'0'*64,'new',badfiles))
 (v.R/'development-2-import-repair/semantic-admission.json').write_bytes(b'planted');reject('validation_not_independent_local_proof',lambda:v.validation_gate(config,p,'0'*64,'new',newfiles))
 for key,value in [('decision','reject'),('gain_gate',False),('latency_gate',False),('losses',[1]),('control_changes',[1])]:
  bad=copy.deepcopy(dev);bad['decision'][key]=value;config=setup_gate(bad);reject('validation_rejected_'+key,lambda:v.validation_gate(config,p,'0'*64,'new',newfiles))
 for key,value in [('all_archive_extracted_bytes_equal',False),('all_raw_source_origin_order_replayed',False),('candidate_sha256','wrong'),('stage','validation')]:
  bad=copy.deepcopy(dev);bad[key]=value;config=setup_gate(bad);reject('validation_bad_'+key,lambda:v.validation_gate(config,p,'0'*64,'new',newfiles))
v.R,v.git,v.input_manifest=old_R,old_git,old_manifest
(R/'private-verifier-controls.json').write_text(json.dumps({'passed':len(passed),'checks':passed,'public_product_or_operator_execution':False},indent=2)+'\n');print('PASS',len(passed),'total private retained/synthetic data checks')
