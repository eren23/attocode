"""Independent original-archive/Git admission of the module-import abort, data-only."""
import hashlib,json,os,pathlib,subprocess,zipfile
R=pathlib.Path(__file__).parent;A=R/'development-1';p=json.loads((A/'admission.json').read_bytes());run=p['run'];report=p['report'];sha=lambda b:hashlib.sha256(b).hexdigest();raw=(A/'artifact.zip').read_bytes()
assert run['id']==40209109644 and run['head_sha']=='c2ce94960aed30c49951cd9df3d34b06e66bbb6b' and type(run['run_attempt'])is int and run['run_attempt']==1 and run['event']=='workflow_dispatch' and run['conclusion']=='failure'
assert sha(raw)==p['archive_sha256']==p['artifact']['digest'].removeprefix('sha256:')
with zipfile.ZipFile(A/'artifact.zip') as z:
 members=z.namelist();assert len(members)==len(set(members))
 for info in z.infolist():
  path=pathlib.PurePosixPath(info.filename);assert not path.is_absolute() and '..' not in path.parts
  if not info.is_dir():assert (A/info.filename).read_bytes()==z.read(info)
 reports=[n for n in members if n.endswith('/report.json')];assert len(reports)==1 and json.loads(z.read(reports[0]))==report
 base=pathlib.PurePosixPath(reports[0]).parent;log=z.read(str(base/'payload.log')).decode();assert "ModuleNotFoundError: No module named 'eval.quality.context_search_experiment'" in log
 assert not any('/context/' in n or n.endswith('/events.jsonl') or n.endswith('/controller-complete.json') for n in members)
 assert str(base/'controller-origin.json') in members
assert report['status']=='incomplete' and report['decision'] is None and report['cleanup_verified'] is True and report['owned_scratch_removed'] is True and 0<=report['seconds']<1
sup=report['supervision'];assert sup['exit_code']==1 and sup['status']=='failed' and sup['cleanup_verified'] is True and sup['log_truncated'] is False
for key,cap in [('peak_rss_bytes',2**31),('peak_disk_bytes',2**31),('peak_evidence_bytes',64*2**20)]:assert type(sup[key])is int and sup[key]<cap
assert report['identity']['commit']==run['head_sha'] and report['identity']['github_run_id']==str(run['id'])
env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'}
for name,digest in report['identity']['files'].items():assert sha(subprocess.check_output(['git','show',run['head_sha']+':'+name],env=env))==digest
result={'status':'admitted-incomplete','run':run['id'],'head':run['head_sha'],'archive_sha256':sha(raw),'seconds':report['seconds'],'quality_decision':None,'fixture_materialization_started':False,'query_or_worker_started':False,'all48_questions_unissued':True,'cause':'Dispatcher inferred context_search_experiment; committed operator is context_experiment. Abort occurred at import before operator.run.','all_archive_extracted_bytes_equal':True,'all_recorded_source_hashes_match_Git':True,'cleanup_verified':True,'local_product_operator_execution':False}
(A/'zero-query-admission.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
