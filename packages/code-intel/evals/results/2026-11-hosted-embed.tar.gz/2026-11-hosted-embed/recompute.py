"""Stdlib recompute of embed_trial.decide() from uploaded rows; imports no repo code.

    python3 recompute.py run-41407001519 ../../designs/2026-10-17-test-source-slot-development.json 5
"""
import hashlib
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path

art, design_path, limit = Path(sys.argv[1]), Path(sys.argv[2]), float(sys.argv[3])
raw = design_path.read_bytes()
design = json.loads(raw)
min_gain = {"development": 2, "validation": 3}[design["split"]]
packs = {g["pack"]: g["commit"] for g in design["repositories"]}
load = lambda d: [json.loads(p.read_text()) for p in sorted(next(art.rglob(d)).glob("*.json"))]
base_runs, cand_runs = load("obs/baseline"), load("obs/candidate")
assert sorted(r["pack"] for r in base_runs) == sorted(packs) == sorted(r["pack"] for r in cand_runs)
digest = hashlib.sha256(raw).hexdigest()
assert all(r["questions_sha256"] == digest and r["commit"] == packs[r["pack"]] for r in base_runs + cand_runs)
assert len({(r["operator_sha256"], r["engine_sha256"]) for r in base_runs + cand_runs}) == 1
base = [q for r in base_runs for q in r["queries"]]
cand = [q for r in cand_runs for q in r["queries"]]
expected = [q["id"] for g in design["repositories"] for q in g["queries"]]
assert sorted(q["id"] for q in base) == sorted(expected) == sorted(q["id"] for q in cand)
by_id = {q["id"]: q for q in cand}

# Pages are worst of three samples: the page hits must equal the intersection.
for q in cand:
    for page in ("5", "24", "scoped"):
        p = q["pages"][page]
        assert len(p["samples"]) == 3
        for m, v in p["hits"].items():
            assert sorted(v) == sorted(set.intersection(*(set(s["hits"][m]) for s in p["samples"]))), (q["id"], page, m)

def total(rows, metric, page):
    return sum(len(r["pages"][page]["hits"][metric]) for r in rows)

losses = Counter()
scoped_loss = False
net = dict.fromkeys(packs, 0)
for old in base:
    new = by_id[old["id"]]
    assert old["query"] == new["query"] and old["evidence"] == new["evidence"]
    net[old["pack"]] += len(new["pages"]["5"]["hits"]["files"]) - len(old["pages"]["5"]["hits"]["files"])
    for page in ("5", "24", "scoped"):
        assert old["pages"][page]["request"] == new["pages"][page]["request"]
        for metric in ("files", "visible"):
            gone = set(old["pages"][page]["hits"][metric]) - set(new["pages"][page]["hits"][metric])
            losses[(page, metric)] += len(gone)
            scoped_loss |= page == "scoped" and bool(gone)

dense = [s["dense"] for q in cand for page in ("5", "24", "scoped") for s in q["pages"][page]["samples"]]
status = Counter(d.get("status", "not_attempted") for d in dense)
attempts = status["ok"] + status["failed"]
secs = sorted(s["seconds"] for q in cand for page in ("5", "24") for s in q["pages"][page]["samples"])
p95 = secs[math.ceil(.95 * len(secs)) - 1]
models = {m for r in cand_runs for m in r["embed_calls"]["models"]}
pinned = bool(models) and all(re.fullmatch(r"(voyageai/)?voyage-code-4(-\d{8})?", m) for m in models)
cost = sum(r["embed_calls"]["cost"] for r in cand_runs)
before = json.loads(next(art.rglob("usage-before.json")).read_text())["usage"]
after = json.loads(next(art.rglob("usage-after.json")).read_text())["usage"]
no_calls = {"posted": 0, "refused": 0, "cost": 0.0, "models": []}
checks = {
    "file_totals_no_loss": all(total(cand, "files", p) >= total(base, "files", p) for p in ("5", "24", "scoped")),
    "visible_totals_no_loss": all(total(cand, "visible", p) >= total(base, "visible", p) for p in ("5", "24", "scoped")),
    "scoped_no_individual_loss": not scoped_loss,
    "inspection_no_net_loss": sum(len(r["inspection_hits"]) for r in cand) >= sum(len(r["inspection_hits"]) for r in base),
    "files_5_gain": sum(net.values()) >= min_gain and sum(v > 0 for v in net.values()) >= 2,
    "no_file_loss_24": losses[("24", "files")] == 0,
    "at_most_one_file_loss_5": losses[("5", "files")] <= 1,
    "packs_indexed": all((r["embed_index"] or {}).get("chunks") and (r["embed_index"] or {}).get("stored")
                         and (r["embed_index"] or {}).get("abort") is None for r in cand_runs),
    "pinned_model": pinned,
    "no_consent_refusal": status["off"] == 0,
    "fallback_rate": bool(attempts) and status["failed"] <= .05 * attempts,
    "search_p95": p95 <= 2.0,
    "baseline_no_remote_calls": all(r["embed_calls"] == no_calls and r["embed_index"] is None for r in base_runs),
    "no_refused_calls": not any(r["embed_calls"]["refused"] for r in cand_runs),
    "spend": cost <= limit and 0 <= after - before <= limit,
}
out = {"passed": all(checks.values()), "checks": checks, "net_by_pack": net,
       "totals": {f"{m}_{p}": [total(base, m, p), total(cand, m, p)]
                  for m in ("files", "visible") for p in ("5", "24", "scoped")},
       "losses": {f"{p}/{m}": n for (p, m), n in losses.items() if n},
       "dense": dict(status), "search_p95": p95, "models": sorted(models),
       "reported_usd": round(cost, 6), "measured_usd": after - before}
print(json.dumps(out, indent=2))
dec = json.loads(next(art.rglob("decision.json")).read_text())
assert dec["checks"] == checks and dec["passed"] == out["passed"], "decision.json disagrees"
print("decision.json matches")
